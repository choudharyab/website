	<footer id="footer" class="col-full">

				<div class='pre-footer'>
					<div class='footer-delivery pre-footer-inner'>
						<div class='pre-footer-img img-same-day'><img src='wp-content/uploads/pre-footer-1.png'></div>
						<div class='pre-footer-text'><p>Same day delivery in Auckland</p></div>
					</div>
					<div class='footer-signup pre-footer-inner'>
						<div class='pre-footer-img img-sign-up'><img src='wp-content/uploads/pre-footer-2.png'></div>
						<div class='pre-footer-text'><p>Sign up to our newsletter</p></div>
					</div>
					<div class='footer-new pre-footer-inner'>
						<div class='pre-footer-img img-check-out'><img src='wp-content/uploads/pre-footer-3.png'></div>
						<div class='pre-footer-text'><p>Check out our new products</p></div>
					</div>
					<div class="footer-newsletter">
						<div class="footer-newsletter-inner">
							
                <div class='gf_browser_unknown gform_wrapper newsletter_signup_wrapper' id='gform_wrapper_2' ><a id='gf_2' class='gform_anchor' ></a><form method='post' enctype='multipart/form-data' target='gform_ajax_frame_2' id='gform_2' class='newsletter_signup' action='https://naturallyorganic.co.nz/#gf_2'>
                        <div class='gform_body'><ul id='gform_fields_2' class='gform_fields top_label form_sublabel_below description_below'><li id='field_2_1' class='gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible' ><label class='gfield_label gfield_label_before_complex' for='input_2_1_3' >Name<span class='gfield_required'>*</span></label><div class='ginput_complex ginput_container no_prefix has_first_name no_middle_name has_last_name no_suffix gf_name_has_2 ginput_container_name gfield_trigger_change' id='input_2_1'>
                            
                            <span id='input_2_1_3_container' class='name_first' >
                                                    <input type='text' name='input_1.3' id='input_2_1_3' value='' aria-label='First name' tabindex='3'  aria-required="true" aria-invalid="false" placeholder='First name'/>
                                                    <label for='input_2_1_3' >First</label>
                                                </span>
                            
                            <span id='input_2_1_6_container' class='name_last' >
                                                    <input type='text' name='input_1.6' id='input_2_1_6' value='' aria-label='Last name' tabindex='5'  aria-required="true" aria-invalid="false" placeholder='Last name'/>
                                                    <label for='input_2_1_6' >Last</label>
                                                </span>
                            
                        </div></li><li id='field_2_2' class='gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_2_2' >Email<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_email'>
                            <input name='input_2' id='input_2_2' type='email' value='' class='medium' tabindex='7'   placeholder='Email address' aria-required="true" aria-invalid="false"/>
                        </div></li><li id='field_2_4' class='gfield gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_2_4' >Region<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_select'><select name='input_4' id='input_2_4'  class='medium gfield_select' tabindex='8'  aria-required="true" aria-invalid="false"><option value='1' >Auckland</option><option value='3' >Bay of Plenty</option><option value='13' >Canterbury</option><option value='21' >Christchurch</option><option value='8' >Coromandel</option><option value='23' >Dunedin</option><option value='11' >Eastland</option><option value='5' >Hamilton</option><option value='15' >Hawkes Bay</option><option value='17' >Manawatu</option><option value='22' >Marlborough</option><option value='14' >Nelson</option><option value='9' >Northland</option><option value='10' >Otago</option><option value='2' >Other</option><option value='16' >Queenstown</option><option value='18' >Rotorua</option><option value='7' >Southland</option><option value='12' >Taranaki</option><option value='20' >Taupo</option><option value='4' >Waikato</option><option value='24' >Wairarapa</option><option value='25' >Wanganui</option><option value='6' >Wellington</option><option value='19' >West Coast</option></select></div></li>
                            </ul></div>
        <div class='gform_footer top_label'> <input type='submit' id='gform_submit_button_2' class='gform_button button' value='Submit' tabindex='9' onclick='if(window["gf_submitting_2"]){return false;}  if( !jQuery("#gform_2")[0].checkValidity || jQuery("#gform_2")[0].checkValidity()){window["gf_submitting_2"]=true;}  ' onkeypress='if( event.keyCode == 13 ){ if(window["gf_submitting_2"]){return false;} if( !jQuery("#gform_2")[0].checkValidity || jQuery("#gform_2")[0].checkValidity()){window["gf_submitting_2"]=true;}  jQuery("#gform_2").trigger("submit",[true]); }' /> <input type='hidden' name='gform_ajax' value='form_id=2&amp;title=&amp;description=&amp;tabindex=2' />
            <input type='hidden' class='gform_hidden' name='is_submit_2' value='1' />
            <input type='hidden' class='gform_hidden' name='gform_submit' value='2' />
            
            <input type='hidden' class='gform_hidden' name='gform_unique_id' value='' />
            <input type='hidden' class='gform_hidden' name='state_2' value='WyJbXSIsImRhNGVhNjRkYWI5ZTljYzA4M2E3YThhMmY5N2Y2YmIzIl0=' />
            <input type='hidden' class='gform_hidden' name='gform_target_page_number_2' id='gform_target_page_number_2' value='0' />
            <input type='hidden' class='gform_hidden' name='gform_source_page_number_2' id='gform_source_page_number_2' value='1' />
            <input type='hidden' name='gform_field_values' value='' />
            
        </div>
                        </form>
                        </div>
                <iframe style='display:none;width:0px;height:0px;' src='about:blank' name='gform_ajax_frame_2' id='gform_ajax_frame_2' title='Ajax Frame'>This iframe contains the logic required to handle Ajax powered Gravity Forms.</iframe>
                <script type='text/javascript'>jQuery(document).ready(function($){gformInitSpinner( 2, 'wp-content/plugins/gravityforms/images/spinner.gif' );jQuery('#gform_ajax_frame_2').load( function(){var contents = jQuery(this).contents().find('*').html();var is_postback = contents.indexOf('GF_AJAX_POSTBACK') >= 0;if(!is_postback){return;}var form_content = jQuery(this).contents().find('#gform_wrapper_2');var is_confirmation = jQuery(this).contents().find('#gform_confirmation_wrapper_2').length > 0;var is_redirect = contents.indexOf('gformRedirect(){') >= 0;var is_form = form_content.length > 0 && ! is_redirect && ! is_confirmation;if(is_form){jQuery('#gform_wrapper_2').html(form_content.html());if(form_content.hasClass('gform_validation_error')){jQuery('#gform_wrapper_2').addClass('gform_validation_error');} else {jQuery('#gform_wrapper_2').removeClass('gform_validation_error');}setTimeout( function() { /* delay the scroll by 50 milliseconds to fix a bug in chrome */ jQuery(document).scrollTop(jQuery('#gform_wrapper_2').offset().top); }, 50 );if(window['gformInitDatepicker']) {gformInitDatepicker();}if(window['gformInitPriceFields']) {gformInitPriceFields();}var current_page = jQuery('#gform_source_page_number_2').val();gformInitSpinner( 2, 'wp-content/plugins/gravityforms/images/spinner.gif' );jQuery(document).trigger('gform_page_loaded', [2, current_page]);window['gf_submitting_2'] = false;}else if(!is_redirect){var confirmation_content = jQuery(this).contents().find('.GF_AJAX_POSTBACK').html();if(!confirmation_content){confirmation_content = contents;}setTimeout(function(){jQuery('#gform_wrapper_2').replaceWith(confirmation_content);jQuery(document).scrollTop(jQuery('#gf_2').offset().top);jQuery(document).trigger('gform_confirmation_loaded', [2]);window['gf_submitting_2'] = false;}, 50);}else{jQuery('#gform_2').append(contents);if(window['gformRedirect']) {gformRedirect();}}jQuery(document).trigger('gform_post_render', [2, current_page]);} );} );</script>						</div>
						<div class="close-nl" id="close-nl"><img src="wp-content/uploads/close-nl.png"></div>
					</div>
				</div>

			<div class="naturally-container footer-widgets-container">
									<section id="footer-widgets" class="col-full col-2 fix">
																					<div class="block footer-widget-1">
						        	<div id="text-17" class="widget widget_text">			<div class="textwidget">
<noscript><IMG class="logo-footer" src="wp-content/uploads/logo_footer.jpg"></noscript>
<img class="logo-footer lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="/wp-content/uploads/logo_footer.jpg">

</div>
		</div><div id="nav_menu-2" class="widget widget_nav_menu"><div class="menu-footer-left-container"><ul id="menu-footer-left-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-220939 current_page_item menu-item-221131"><a href="index.html">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220291"><a href="about-us/index.html">About Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220292"><a href="contact-us/index.html">Contact Us</a></li>
</ul></div></div><div id="text-18" class="widget widget_text">			<div class="textwidget">
<h6>Online enquiries</h6>
<p>09 914 2026</p>

<h6>Online order pick ups</h6>
<p>Naturally Organic Warehouse<br>
Before 2:30pm<br>
12/18 Corinthian Drive<br>
Albany<br>
Next to PBT Couriers</p>

</div>
		</div>								</div>
					        																					<div class="block footer-widget-2">
						        	<div id="nav_menu-3" class="widget widget_nav_menu"><h3>Shop Online</h3><div class="menu-footer-right-container"><ul id="menu-footer-right-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220293"><a href="product-category/baby/index.html">Baby</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220294"><a href="product-category/bakery/index.html">Bakery</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220295"><a href="product-category/beverages/index.html">Beverages</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220296"><a href="product-category/chilled/index.html">Chilled</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220297"><a href="product-category/fruit-vegetables/index.html">Fruit &#038; Vegetables</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220298"><a href="product-category/grocery/index.html">Grocery</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220299"><a href="product-category/health/index.html">Health</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220300"><a href="product-category/household/index.html">Household</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-220301"><a href="product-category/personal/index.html">Personal</a></li>
</ul></div></div><div id="text-16" class="widget widget_text">			<div class="textwidget">
<h6>Shop in store</h6>
<p>Mega Lifestyle Store and Café Bar<br>
Shop 23, 100 Don McKinnon Drive<br>
Northridge Plaza, Albany<br>
Ph: (09) 447 3508 for the retail store only</p>

<p>Monday to Friday: 7.00am to 6.00pm<br>
Saturday: 8.00am to 5.00pm<br>
Sunday: 9.00am to 5.00pm<br>
Cafe Bar serving daily till store close</p>

<p><a href="360-virtual-tour/index.html">Take a 360° Virtual Tour</a></p>

</div>
		</div>								</div>
					        											</section><!-- /#footer-widgets  -->
							</div>

			<div class="bottom-footer naturally-container">
				<div id="copyright" class="col-left">
									<p>Naturally Organic &copy; 2018. All Rights Reserved.</p>
								</div>
				<div id="credit" class="col-right">
		        <p></p>				</div>
			</div>
		</footer><!-- /#footer  -->