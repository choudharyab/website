@extends('admin_views.layout.website_layout')
@section('content')
<div class="container nonpad">
   <section id="wrapper">
      <aside id="notifications">
         <div class="container">
         </div>
      </aside>
      <div class="container padd_both">
         <div class="row">
            <div id="content-wrapper">
               <br/><br/><br/>
               <section id="main">
                  <div class="cart-grid row nonpad">
                     <!-- Left Block: cart product informations & shpping -->
                     <div class="cart-grid-body col-xs-12 col-lg-8 nonpad">
                        <!-- cart products detailed -->
                              @if(session()->has('message'))
                                <div class="alert alert-success">
                                    {{ session()->get('message') }}
                                </div>
                            @endif

                        <div class="card cart-container">
                           <div class="card-block">
                              <h1 class="h1">Checkout</h1>
                           </div>
                           <hr>
                           <div class="cart-overview js-cart">
                              <section id="checkout">
                                 <button class="options">
                                 <i class="fa fa-caret-down"></i>1 .Login or Signup
                                 </button>
                                 <div id="cart" class="">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pasd">
                                       <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                          <form enctype="multipart/form-data" id="upload_form1" role="form" 
                                             method="POST" action="" >
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="email_mobile" id="login_email_mobile" type="text" value="" placeholder="Email/Mobile" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="password" id="login_password" type="password" value=""  placeholder="Password" required>
                                                </div>
                                             </div>
                                             <button type="submit"  id="user_login" class="btn btn-primary add-to-cart login-but">
                                             Login
                                             </button>
                                             <p  style="color: #c454e6;font-size: 12px;
                                                text-align: center;" id="login_success"></p>
                                          </form>
                                       </div>
                                       <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 left_align ">
                                          <form enctype="multipart/form-data" id="upload_form" role="form" method="POST" action="" >
                                             <div class="form-group">
                                                <div class="fsf">
                                                   <input class="form-control passs" name="full_name"  type="text" value="" placeholder="Full Name" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="email_mobile"  type="email" value="" placeholder="Email/Mobile" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="password"  type="password" value=""  placeholder="Set Password" required>
                                                </div>
                                             </div>
                                             <button  type="submit"  id="register" class="btn btn-primary add-to-cart login-but">
                                             Signup
                                             </button>
                                             <p  style="color: #c454e6;font-size: 12px;
                                                text-align: center;" id="register_success"></p>
                                          </form>
                                       </div>
                                    </div>
                                    <!-- <div class="class_save">Data Save Successfully Go To the Next </div>-->
                                 </div>
                                 <button class="options">
                                 <i class="fa fa-caret-down"></i>2. Delivery Address
                                 </button>
                                 <div class="form1"  id="delivery">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pasd">
                                       <form enctype="multipart/form-data" id="upload_form2" role="form" 
                                          method="POST" action="" >
                                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="name"  type="text" value="" placeholder="Full Name" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="mobile_no"  type="text" value=""  placeholder="Mobile No" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="address_line1"  type="text" value=""  placeholder="Address Line1" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="address_line2"  type="text" value=""  placeholder="Address Line2" required>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="email"  type="text" value=""  placeholder="Email" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="city"  type="text" value=""  placeholder="City" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="state"  type="text" value=""  placeholder="State" required>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <div class="">
                                                   <input class="form-control passs" name="alternate_no"  type="text" value=""  placeholder="Alternate No" required>
                                                </div>
                                             </div>
                                          </div>
                                       </form>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                       <div class="checkout text-xs-center card-block">
                                         <p id="address_success" style="color: #c454e6;font-size: 12px;
                                                text-align: center;" ></p>
                                          <button class="btn btn-primary " type="submit" id="delivery_address" style="margin: 0;"> Save</button>
                                          
                                       </div>
                                    </div>
                                   
                                 </div>
                                 <button class="options">
                                 <i class="fa fa-caret-down"></i>3. Order Summary
                                 </button>
                                 <div class="form1" id="shipping">
                                     <form enctype="multipart/form-data" id="upload_form3" role="form" 
                                 method="POST" action="" >
                                 <div class="cart-overview js-cart">
                                    <?php  $i=0;?>
                                    @foreach($cart as $item)  
                                    <input type="hidden" name="product_id[{{$i}}]" value="{{$item['id']}}">
                                    <input type="hidden" name="rate[{{$i}}]" value="{{$item['price']}}">
                                    <input type="hidden" name="shipping_id[{{$i}}]" value="{{$shipping_id}}">
                                    <div class="select_item col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                                       <div>
                                          <a href="{{URL::to('removeCart/'.$item['id'])}}">
                                          <i class="fa fa-times-circle cross_icon" aria-hidden="true"></i>
                                          </a>
                                       </div>
                                       <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                                          <center>
                                          @if(!empty($item['options']['image_name']))
                                          <img src="{{URL::asset('public/uploadimages/'.$item['options']['image_name'])}}"/>
                                          @endif
                                          <center>
                                             <div class="product-add-to-cart acs">
                                                <div class="input-group spinner">
                                                   <input  class="form-control" id="number_{{$item['id']}}" name="qty[{{$i}}]" 
                                                      type="text" value="{{$item['qty']}}" min="0" max="32">
                                                   <div class="input-group-btn-vertical butt buttons">
                                                      <button class="btn btn-default increment" onclick='increment({{$item['price']}},{{$item['id']}})'
                                                      type="button"><i class="fa fa-angle-up"></i></button>
                                                      <button class="btn btn-default decrement" onclick='decrement({{$item['price']}},{{$item['id']}})'
                                                      type="button"><i class="fa fa-angle-down"></i></button>
                                                   </div>
                                                </div>
                                                <div class="clearfix"></div>
                                             </div>
                                               <p></p>
                                                @if(!empty($item['qty5']))
                                               <!--  <button style="width: 20px;height: 20px;" onclick='qty5({{$item['price']}},{{$item['id']}})'
                                                  type="button" value="5">5</button>
                                                 @endif
                                                 @if(!empty($item['qty10']))
                                                 <button style="width: 20px;height: 20px;" onclick='qty10({{$item['price']}},{{$item['id']}})'
                                                  type="button" value="10">10</button>
                                                 @endif
                                                  @if(!empty($item['qty20']))
                                                 <button style="width: 20px;height: 20px;" onclick='qty20({{$item['price']}},{{$item['id']}})'
                                                  type="button" value="20">20</button>-->
                                                 @endif 
                                          </center>
                                       </div>
                                       <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
                                          <h1 class="laber-product-title"><a href="">{{$item['name']}}</a></h1>
                                          <div class="top_m">
                                             <span class="rsru" id="{{$item['id']}}">{{$item['price']}}</span>
                                            <!-- <span><strike>$ 0.00</strike></span>
                                             <span class="dis">68 % Off</span>-->
                                          </div>
                                          <div class="top_m  color333">Delivery in 7-8 days</div>
                                          <div>10 Days Replacement Policy</div>
                                       </div>
                                       <div class="clearfix"></div>
                                    </div>
                                    <?php  $i++;?>
                                    @endforeach
                                    <?php 
									$subtotal=0;
									$total_qty =0;
									
									?>
                                    @foreach($cart as $item)
                                    <?php 
									
									$total_qty +=$item['qty'];
									$subtotal=$subtotal+($item['price'] * $item['qty']);
									
									
									?>
                                    @endforeach
									<?php
									   if(isset($coupon_amount) && is_numeric($coupon_amount) ){
									   $sub_total1  =  $subtotal - $coupon_amount;
									   }else{
										   $sub_total1  =  $subtotal ;
									   }
									   if(isset($shipping_amount) && is_numeric($shipping_amount)){
									     $final_total  =  $sub_total1 + $shipping_amount;
									   }else{
										   $final_total = $sub_total1 ;
									   }
									   
									?>
                                    <div class="clearfix"></div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                       <div class="checkout text-xs-center card-block">
                                          <p style="color: #c454e6;font-size: 12px;
                                                text-align: center;" id="order_success"></p>
                                          <button class="btn btn-primary" type="submit" id="place_order" style="margin: 0;"> Save</button>
                                         
                                       </div>
                                    </div>
                                   
                                 </div>
                              </form>
                                 </div>
                                 <button class="options">
                                 <i class="fa fa-caret-down"></i>4. Payment Option
                                 </button>
                                 <div class="form1" id="payment">
                                    <form enctype="multipart/form-data" id="upload_form4" role="form" method="POST" action="" >
                                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pasd">
                                    <div>
                                       <input type="radio" name="payment_mode" value="online payment" id="1" checked=""/> <label for="1" class="font-18">Proceed To Online Payment</label>
                                    </div>
                                    <div >
                                       <input type="radio" name="payment_mode" value="cash on delivery" id="2"/> <label for="2" class="font-18">Cash on Delivery</label>
                                    </div>
                                    <input type="hidden" name="total1" id="total1" value="{{$final_total}}"/>
                                    <div id="payment_success" class="class_save"></div>
                                 </div>
                                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="checkout text-xs-center card-block">
                                       <button class="btn btn-primary " type="button" id="payment_mode" style="margin: 0;"> Confirm Order</button>
                                    </div>
                                 </div>
                              </form>
                                 </div>
                              </section>
                              <!--<span class="no-items">There are no more items in your cart</span>-->
                              <div class="clearfix"></div>
                              <div class="clearfix"></div>
                           </div>
                        </div>
                        <!-- shipping informations -->
                     </div>
                     <!-- Right Block: cart subtotal & cart total -->
                      <div class="cart-grid-right col-xs-12 col-lg-4 nonpad">
                     <div class="card cart-summary">
                        <div class="cart-detailed-totals">
                           <div class="card-block">
                              <div class="cart-summary-line" id="cart-subtotal-products">
                                 <span class="label js-subtotal">
                                 {{$total_qty }} items
                                 </span>
                                 <span class="value" id="subtotal">{{$subtotal}}</span>
                              </div>
                             <div class="cart-summary-line" id="cart-subtotal-products">
                                 <span class="label js-subtotal">
                                Discount 
                                 </span>
                                 <span class="value" >$ <span id="discount" >{{$coupon_amount}}</span></span>
								 <input type="hidden" id="coupon_id"  value="{{$coupon_id}}" />
                              </div>
                           </div>
                           <hr>
						    <div class="card-block">
							     <div class="cart-summary-line" id="cart-subtotal-products">
                                 <span class="label js-subtotal">
                              <b>  Subtotal </b>
                                 </span>
                                 <span class="value" >$ <span id="subtotal1"> {{$sub_total1}} </span></span>
                              </div>
                             <div class="cart-summary-line" id="cart-subtotal-products">
                                 <span class="label js-subtotal">
                                Shipping
                                 </span>
                                 <span class="value"  >$ <span id="shipping_amount">{{$shipping_amount}} </span></span>
                              </div>
							</div>
                           <div class="card-block">
                              <div class="cart-summary-line cart-total">
                                 <span class="label"><b>Total (tax incl.)</b></span>
                                 <span class="value"><b>$</b><b id="total">{{$final_total}}</b></span>
                              </div>
                           </div>
                           <hr>
                        </div>
                     </div>
                  </div>
                  </div>
               </section>
            </div>
         </div>
      </div>
   </section>
</div>
<script>
   const opt = document.getElementsByClassName("options")
   toggleMenu(opt[0])
   
   for (let i = 0; i < opt.length; i++) {
     opt[i].onclick = function() {
       toggleMenu(this)
       for (let node of opt) {
         if (node !== this)
           closeMenus(node)
       }
     }
   }
   
   function toggleMenu(that) {
     that.classList.toggle("active")
     let form = that.nextElementSibling
     if (form.style.maxHeight) {
       form.style.maxHeight = null
       toggleConfirmIcon(that)
     }
     else
       form.style.maxHeight = `${form.scrollHeight}px`
   }
   
   function closeMenus(that) {
     that.classList.remove("active")
     let form = that.nextElementSibling
     if (form.style.maxHeight) {
       form.style.maxHeight = null
       toggleConfirmIcon(that)
     }
   }
   
   function toggleConfirmIcon(that) {
     let form = that.nextElementSibling
     form.setAttribute("data-completed", setFormCompletion(that))
     if (form.getAttribute("id") === 'summary') { 
       let total = 0
       for (let node of opt) {
         let f = node.nextElementSibling
         if (f.id !== 'summary' && f.getAttribute('data-completed'))
           total++
       }
       if (total === opt.length)
         
       setConfirmIconClass(that)
     } else {
       setConfirmIconClass(that)
     }
   }
   
   function setConfirmIconClass(that) {
     let confirmIcon = that.children[1]
     if (that.getAttribute("data-completed") === 'true') {
       confirmIcon.classList.remove("fa-times-circle")
       confirmIcon.classList.add("fa", "fa-check-circle")
     } else {
       confirmIcon.classList.remove("fa-check-circle")
       confirmIcon.classList.add("fa", "fa-times-circle")
     }
   }
   
   function setFormCompletion(that) {
     let form = that.nextElementSibling
     inputNodes = form.getElementsByTagName('input')
     let completedFields = 0,
         totalFields = inputNodes.length
     for (let i = 0; i < totalFields; i++) {
       if (inputNodes[i]['type'] !== "checkbox")  {
         if (inputNodes[i]['type'] === "radio" && inputNodes[i].checked)
           return true
         else if (inputNodes[i].value && inputNodes[i]['type'] !== "radio")
           completedFields++
       } else {
         completedFields++
       }
     }
     if (completedFields === totalFields)
       return true
     else
       return false
   }
</script>
<script>
   function increment($price,$id){  
      /* $qty=$("#number_"+$id).val();
       $qty1=parseFloat($qty)+1;
       $new_price= parseFloat($qty1)*parseFloat($price);
         $("#"+$id).text(parseFloat($new_price));
         getTotal();*/
     $qty=$("#number_"+$id).val();
     $qty1=parseFloat($qty)+1;
         $.ajax({
            url:'{{url("edit_product_qty")}}',
            type:'POST',
            data:{product_id:$id,quantity:$qty1},
            success: function(response){
                if(response.flag == 'true'){
                    $("#"+$id).text(parseFloat(response.price)); 
                      getTotal();
                   }
                 }
            });
      getTotal();
   }
   
   function decrement($price,$id){  
       /*$qty=$("#number_"+$id).val();
        $qty1=parseFloat($qty)-1; 
       $new_price= parseFloat($qty1)*parseFloat($price);
         $("#"+$id).text(parseFloat($new_price));
         getTotal();*/
     $qty=$("#number_"+$id).val();
     $qty1=parseFloat($qty)-1; 
     $.ajax({
            url:'{{url("edit_product_qty")}}',
            type:'POST',
            data:{product_id:$id,quantity:$qty1},
            success: function(response){
                if(response.flag == 'true'){
                    $("#"+$id).text(parseFloat(response.price)); 
                      getTotal();
                   }
                 }
            });
    getTotal();
   }
   function qty5($price,$id){  
     $qty1=5;
      $qty=$("#number_"+$id).val($qty1);
         $.ajax({
            url:'{{url("edit_product_qty")}}',
            type:'POST',
            data:{product_id:$id,quantity:$qty1},
            success: function(response){
                if(response.flag == 'true'){
                    $("#"+$id).text(parseFloat(response.price)); 
                      getTotal();
                   }
                 }
            });
      getTotal();
}

function qty10($price,$id){  
     $qty1=10;
      $qty=$("#number_"+$id).val($qty1);
         $.ajax({
            url:'{{url("edit_product_qty")}}',
            type:'POST',
            data:{product_id:$id,quantity:$qty1},
            success: function(response){
                if(response.flag == 'true'){
                    $("#"+$id).text(parseFloat(response.price)); 
                      getTotal();
                   }
                 }
            });
      getTotal();
}
function qty20($price,$id){  
     $qty1=20;
      $qty=$("#number_"+$id).val($qty1);
         $.ajax({
            url:'{{url("edit_product_qty")}}',
            type:'POST',
            data:{product_id:$id,quantity:$qty1},
            success: function(response){
                if(response.flag == 'true'){
                    $("#"+$id).text(parseFloat(response.price)); 
                      getTotal();
                   }
                 }
            });
      getTotal();
}
   function getTotal(){
       var total = 0;
       $(".rsru").each(function(){
           total += parseFloat(this.innerHTML);
       });
       $("#subtotal").text(parseFloat(total));
       $("#total").text(parseFloat(total));
       $("#total1").val(parseFloat(total));
   }
</script>
<script>
   $("#register").click(function(e){
        e.preventDefault();
           var form=$("#upload_form")[0];
           var fd =new FormData(form);
          $.ajax({
                 url: '{{url("register")}}',
                 data:fd,
                 async:false,
                 type: 'POST',
                 processData: false,
                 contentType: false,
            success:function(response){
                if(response.flag=="true")
                   {
                          $("#register_success").html("Data Save Successfully Go To the Next");
                   }
                   else
                    {
                         $("#register_success").html('User is already registered please Login');
                    } 
            },
          });
   
    });
   
    $("#user_login").click(function(e){
        e.preventDefault();
           var form=$("#upload_form1")[0];
           var fd =new FormData(form);
         if($("#login_email_mobile").val()=="")
        {
           $("#login_success").html("Please Enter the Email Or Mobile No");
        }else if($("#login_password").val()=="" )
        {
          $("#login_success").html("Please Enter the Password");
        }
        else
        {
            $.ajax({
                 url: '{{url("user_login")}}',
                 data:fd,
                 async:false,
                 type: 'POST',
                 processData: false,
                 contentType: false,
                success:function(response){
                if(response.flag=="true")
                   {
                          $("#login_success").html("Data Save Successfully Go To the Next");
                   }
                   else
                    {
                         $("#login_success").html('Invalid Email/Mobile Or Password');
                    } 
            },
          });
       }
   
    });
</script>
<script>
   $("#delivery_address").click(function(e){
      e.preventDefault();
         var form=$("#upload_form2")[0];
         var fd =new FormData(form);
          $.ajax({
               url: '{{url("delivery_address")}}',
               data:fd,
               async:false,
               type: 'POST',
               processData: false,
               contentType: false,
              success:function(response){
              if(response.flag=="true")
                 {
                        $("#address_success").html("Data Save Successfully Go To the Next");
                 }
                 else
                  {
                       $("#address_success").html('Unable to save the Address');
                  } 
          },
        });
   
   });
</script>
<script>
   $("#place_order").click(function(e){
      e.preventDefault();
         var form=$("#upload_form3")[0];
         var fd =new FormData(form);
          $.ajax({
               url: '{{url("place_order")}}',
               data:fd,
               async:false,
               type: 'POST',
               processData: false,
               contentType: false,
              success:function(response){
              if(response.flag=="true")
                 {
                        $("#order_success").html("Data Save Successfully Go To the Next");
                 }
                 else
                  {
                       $("#order_success").html('Unable to save the Address');
                  } 
          },
        });
   
   });
</script>
<script>
   $("#payment_mode").click(function(e){
      e.preventDefault();
	  
	  var shipping_amount =$("#shipping_amount").text();
	  var discount =$("#discount").text();
	  var coupon_id =$("#coupon_id").val();
         var form=$("#upload_form4")[0];
         var fd =new FormData(form);
		 fd.append('shipping_amount', shipping_amount);
		 fd.append('coupon_amount', discount);
		 fd.append('coupon_id', coupon_id);
          $.ajax({
               url: '{{url("payment_mode")}}',
               data:fd,
               async:false,
               type: 'POST',
               processData: false,
               contentType: false,
              success:function(response){
				   //alert(response);
              if(response.flag=="true")
                 {
					
                        //$("#order_success").html("Data Save Successfully Go To the Next");
                         window.location ='{{url("pay")}}';
                 }
                 else if(response.flag=="false")
                  {
                       //$("#payment_success").html('Order save Successfully');
                         window.location ='{{url("checkout_success")}}';
                  } 
          },
        });
   
   });
</script>

@stop