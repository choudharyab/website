<?php error_reporting(0); ?>

<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from naturallyorganic.co.nz/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 02 Nov 2018 17:15:41 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<!-- Google Tag Manager
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5W86GQ6');</script> -->
<!-- End Google Tag Manager -->

<meta charset="UTF-8" />

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="pingback" href="xmlrpc.php" />




<!-- Woo Custom Styling -->
<style type="text/css">
a:hover, .post-more a:hover, .post-meta a:hover, .post p.tags a:hover { color: #704D36 !important; }
</style>

<!-- Woo Custom Typography -->
<style type="text/css">
body { font:normal 1.4em/1.5em Arial, sans-serif;color:#4b4b4b; }
.nav a, #navigation .cart a { font:300 1em/1.4em Arial, sans-serif;color:#ffffff; }
.page header h1 { font:bold 1.4em/1em Arial, sans-serif;color:#704d36; }
.post header h1 { font:300 28px/1em Arial, sans-serif;color:#704d36; }
.post-meta { font:300 12px/1em Arial, sans-serif;color:#999999; }
.entry, .entry p { font:300 1em/1.5em Arial, sans-serif;color:#4b4b4b; } h1, h2, h3, h4, h5, h6 { font-family: Arial, sans-serif, arial, sans-serif; }
.widget h3 { font:bold 1em/1em Arial, sans-serif;color:#704d36; }
.widget h3 { font:bold 1em/1em Arial, sans-serif;color:#704d36; }
</style>

<!-- Alt Stylesheet -->

<!-- Options Panel Custom CSS -->
<style type="text/css">
#footer-widgets .footer-widget-2 .widget_text h3:first-child {
color: #704d36;
}
</style>


<!-- Custom Stylesheet -->

    <!-- Predictive Search Widget Template Registered -->
    
    <script type="text/template" id="wc_psearch_itemTpl">
	<div class="ajax_search_content">
	<div class="result_row">
		<a href="">
			<span class="rs_avatar"><img src="" /></span>
			<div class="rs_content_popup">
				<span class="rs_name"></span>
				
			</div>
		</a>
	</div>
</div></script>

<script type="text/template" id="wc_psearch_footerSidebarTpl"><div rel="more_result" class="more_result">
		<span>See more search results for &#039;&#039; in:</span>
		
</div></script><script type="text/template" id="wc_psearch_footerHeaderTpl"><div rel="more_result" class="more_result">
		<span>See more search results for &#039;&#039; in:</span>
		
</div></script>
    
<!-- This site is optimized with the Yoast SEO plugin v8.1 - https://yoast.com/wordpress/plugins/seo/ -->
<title>Home - Naturally Organic</title>
<link rel="canonical" href="index.html" />
<script type='application/ld+json'>{"@context":"https:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/naturallyorganic.co.nz\/","name":"Naturally Organic","potentialAction":{"@type":"SearchAction","target":"https:\/\/naturallyorganic.co.nz\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='http://cdnjs.cloudflare.com/' />
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://ajax.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="Naturally Organic &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Naturally Organic &raquo; Comments Feed" href="comments/feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/naturallyorganic.co.nz\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.6"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>

<script type='text/javascript'>
/* <![CDATA[ */
var gadwpUAEventsData = {"options":{"event_tracking":"1","event_downloads":"zip|mp3*|mpe*g|pdf|docx*|pptx*|xlsx*|rar*","event_bouncerate":0,"aff_tracking":1,"event_affiliates":"\/out\/","hash_tracking":0,"root_domain":"naturallyorganic.co.nz","event_timeout":100,"event_precision":0,"event_formsubmit":0,"ga_pagescrolldepth_tracking":1,"ga_with_gtag":0}};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/google-analytics-dashboard-for-wp/front/js/tracking-analytics-events6ab9.js?ver=5.3.5'></script>
<script type='text/javascript' src='wp-content/plugins/google-analytics-dashboard-for-wp/front/js/tracking-scrolldepth6ab9.js?ver=5.3.5'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"https:\/\/naturallyorganic.co.nz\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min8dc7.js?ver=2.6.13'></script>
<script type='text/javascript' src='wp-content/plugins/gift-cards-for-woocommerce/assets/js/scripts1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart0147.js?ver=4.12'></script>
<script type='text/javascript' src='wp-content/themes/superstore/includes/js/third-party1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/superstore/includes/js/jquery.tiptip.min1845.js?ver=4.9.6'></script>




<style>.lazyload {
	display: block;
}

.lazyload,
        .lazyloading {
			opacity: 0;
		}
		
		
		.lazyloaded {
			opacity: 1;
			transition: opacity 300ms;
		}.lazyloading {
  color: transparent;
  opacity: 1;
  transition: opacity 300ms;
  background: url("data:image/svg+xml,%3Csvg%20width%3D%2244%22%20height%3D%2244%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20stroke%3D%22%233a3a3a%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%20stroke-width%3D%222%22%3E%3Ccircle%20cx%3D%2222%22%20cy%3D%2222%22%20r%3D%221%22%3E%3Canimate%20attributeName%3D%22r%22%20begin%3D%220s%22%20dur%3D%221.8s%22%20values%3D%221%3B%2020%22%20calcMode%3D%22spline%22%20keyTimes%3D%220%3B%201%22%20keySplines%3D%220.165%2C%200.84%2C%200.44%2C%201%22%20repeatCount%3D%22indefinite%22%2F%3E%3Canimate%20attributeName%3D%22stroke-opacity%22%20begin%3D%220s%22%20dur%3D%221.8s%22%20values%3D%221%3B%200%22%20calcMode%3D%22spline%22%20keyTimes%3D%220%3B%201%22%20keySplines%3D%220.3%2C%200.61%2C%200.355%2C%201%22%20repeatCount%3D%22indefinite%22%2F%3E%3C%2Fcircle%3E%3Ccircle%20cx%3D%2222%22%20cy%3D%2222%22%20r%3D%221%22%3E%3Canimate%20attributeName%3D%22r%22%20begin%3D%22-0.9s%22%20dur%3D%221.8s%22%20values%3D%221%3B%2020%22%20calcMode%3D%22spline%22%20keyTimes%3D%220%3B%201%22%20keySplines%3D%220.165%2C%200.84%2C%200.44%2C%201%22%20repeatCount%3D%22indefinite%22%2F%3E%3Canimate%20attributeName%3D%22stroke-opacity%22%20begin%3D%22-0.9s%22%20dur%3D%221.8s%22%20values%3D%221%3B%200%22%20calcMode%3D%22spline%22%20keyTimes%3D%220%3B%201%22%20keySplines%3D%220.3%2C%200.61%2C%200.355%2C%201%22%20repeatCount%3D%22indefinite%22%2F%3E%3C%2Fcircle%3E%3C%2Fg%3E%3C%2Fsvg%3E") no-repeat;
  background-size: 2em 2em;
  background-position: center center;
}

.lazyloaded {
  transition: none;
}</style><noscript><style>.lazyload { display: none; }</style></noscript>		<!--[if lt IE 8]>
		<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE8.js"></script>
		<![endif]-->
		
<!-- Theme version -->
<meta name="generator" content="BBT Framework 1.0" />
<meta name="generator" content="Superstore 1.0.13" />
<meta name="generator" content="WooFramework 5.5.5" />

<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<!--  Mobile viewport scale | Disable user zooming as the layout is optimised -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!--[if lt IE 9]>
<script src="https://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
		<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://naturallyorganic.co.nz/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><!--[if IE  8]><link rel="stylesheet" type="text/css" href="https://naturallyorganic.co.nz/wp-content/plugins/js_composer/assets/css/vc-ie8.min.css" media="screen"><![endif]-->
<!-- BEGIN ExactMetrics v5.3.5 Universal Analytics - https://exactmetrics.com/ -->

<!-- END ExactMetrics Universal Analytics -->

<!-- UberMenu CSS - Controlled through UberMenu Options Panel 
================================================================ -->
<style type="text/css" id="ubermenu-style-generator-css">
/* Style Generator Styles */
#megaMenu {
  border:none;
  border-bottom:;
  background-color:transparent;
  background:-webkit-gradient(linear,left top,left bottom,from(transparent),to(transparent));
  background:-webkit-linear-gradient(top,transparent,transparent);
  background:-moz-linear-gradient(top,transparent,transparent);
  background:-ms-linear-gradient(top,transparent,transparent);
  background:-o-linear-gradient(top,transparent,transparent);
  -webkit-border-radius:0px;
  -moz-border-radius:0px;
  border-radius:0px;
  -moz-background-clip:padding;
  -webkit-background-clip:padding-box;
  background-clip:padding-box;
  -webkit-box-shadow:inset 0px 1px 0px 0px rgba(255,255,255,0);
  -moz-box-shadow:inset 0px 1px 0px 0px rgba(255,255,255,0);
  box-shadow:inset 0px 1px 0px 0px rgba(255,255,255,0);
}
#megaMenu ul.megaMenu > li.menu-item > a, #megaMenu ul.megaMenu > li.menu-item > span.um-anchoremulator {
  font-size:13px;
  color:#ffffff;
  padding:9px 12px;
  font-weight:normal;
}
#megaMenu.megaMenuHorizontal ul.megaMenu > li.menu-item:first-child > a {
  border-top-left-radius:0px;
  border-bottom-left-radius:0px;
}
#megaMenu.megaMenuHorizontal ul.megaMenu > li.menu-item > a, #megaMenu.megaMenuHorizontal ul.megaMenu > li.menu-item > span.um-anchoremulator {
  border-left:1px solid transparent;
  -webkit-box-shadow:inset 1px 0px 0px 0px rgba(255,255,255,0);
  -moz-box-shadow:inset 1px 0px 0px 0px rgba(255,255,255,0);
  box-shadow:inset 1px 0px 0px 0px rgba(255,255,255,0);
}
#megaMenu.megaMenuVertical ul.megaMenu > li.menu-item > a, #megaMenu.megaMenuVertical ul.megaMenu > li.menu-item > span.um-anchoremulator {
  border-top:1px solid transparent;
  -webkit-box-shadow:inset 0px 1px 0px 0px rgba(255,255,255,0);
  -moz-box-shadow:inset 0px 1px 0px 0px rgba(255,255,255,0);
  box-shadow:inset 0px 1px 0px 0px rgba(255,255,255,0);
}
#megaMenu ul li.menu-item.ss-nav-menu-reg li.menu-item.megaReg-with-sub > a, #megaMenu ul li.menu-item.ss-nav-menu-reg li.menu-item.megaReg-with-sub > span.um-anchoremulator, #megaMenu ul li.menu-item.mega-with-sub > a, #megaMenu ul li.menu-item.mega-with-sub > span.um-anchoremulator, #megaMenu ul li.menu-item.ss-nav-menu-mega > a, #megaMenu ul li.menu-item.ss-nav-menu-mega > span.um-anchoremulator { padding-right:17px; }
#megaMenu ul.megaMenu > li.menu-item > a span.wpmega-link-title, #megaMenu ul.megaMenu > li.menu-item > span.um-anchoremulator span.wpmega-link-title {
  text-transform:none;
  text-shadow:0 -1px 1px transparent;
}
#megaMenu ul.megaMenu > li.menu-item:hover > a, #megaMenu ul.megaMenu > li.menu-item > a:hover, #megaMenu ul.megaMenu > li.menu-item.megaHover > a, #megaMenu ul.megaMenu > li.menu-item:hover > span.um-anchoremulator, #megaMenu ul.megaMenu > li.menu-item > span.um-anchoremulator:hover, #megaMenu ul.megaMenu > li.menu-item.megaHover > span.um-anchoremulator {
  color:#bdde3d !important;
  border-bottom-color:transparent !important;
  background-color:transparent;
  background:-webkit-gradient(linear,left top,left bottom,from(transparent),to(transparent));
  background:-webkit-linear-gradient(top,transparent,transparent);
  background:-moz-linear-gradient(top,transparent,transparent);
  background:-ms-linear-gradient(top,transparent,transparent);
  background:-o-linear-gradient(top,transparent,transparent);
  -webkit-box-shadow:inset 1px 1px 0px 0px rgba(255,255,255,0);
  -moz-box-shadow:inset 1px 1px 0px 0px rgba(255,255,255,0);
  box-shadow:inset 1px 1px 0px 0px rgba(255,255,255,0);
}
#megaMenu ul.megaMenu > li.menu-item:hover > a span.wpmega-link-title, #megaMenu ul.megaMenu > li.menu-item:hover > span.um-anchoremulator span.wpmega-link-title, #megaMenu ul.megaMenu > li.menu-item > a:hover span.wpmega-link-title, #megaMenu ul.megaMenu > li.menu-item > span.um-anchoremulator:hover span.wpmega-link-title, #megaMenu ul.megaMenu > li.menu-item.megaHover > a span.wpmega-link-title, #megaMenu ul.megaMenu > li.menu-item.megaHover > span.um-anchoremulator span.wpmega-link-title { text-shadow:0 -1px 1px transparent; }
#megaMenu ul.megaMenu > li.menu-item.current-menu-item > a, #megaMenu ul.megaMenu > li.menu-item.current-menu-parent > a, #megaMenu ul.megaMenu > li.menu-item.current-menu-ancestor > a { color:#bdde3d; }
#megaMenu ul.megaMenu > li.menu-item.ss-nav-menu-mega > ul.sub-menu-1, #megaMenu ul.megaMenu li.menu-item.ss-nav-menu-reg ul.sub-menu {
  border-color:#7b5e47;
  color:#ffffff;
  text-shadow:0px 1px 1px transparent;
  -webkit-box-shadow:1px 1px 1px transparent;
  -moz-box-shadow:1px 1px 1px transparent;
  box-shadow:1px 1px 1px transparent;
  background-color:#7b5e47;
  background:-webkit-gradient(linear,left top,left bottom,from(#7b5e47),to(#7b5e47));
  background:-webkit-linear-gradient(top,#7b5e47,#7b5e47);
  background:-moz-linear-gradient(top,#7b5e47,#7b5e47);
  background:-ms-linear-gradient(top,#7b5e47,#7b5e47);
  background:-o-linear-gradient(top,#7b5e47,#7b5e47);
}
#megaMenu ul.megaMenu ul.sub-menu .wpmega-postlist a { color:#ffffff; }
#megaMenu.megaMenuHorizontal ul.megaMenu > li.menu-item.ss-nav-menu-mega > ul.sub-menu-1, #megaMenu.megaMenuHorizontal ul.megaMenu li.menu-item.ss-nav-menu-reg > ul.sub-menu { border-top:; }
#megaMenu ul.megaMenu > li.menu-item.ss-nav-menu-mega > ul.sub-menu-1 > li.menu-item { min-width:100px; }
#megaMenu ul li.menu-item.ss-nav-menu-mega ul.sub-menu-1 > li.menu-item > a, #megaMenu ul li.menu-item.ss-nav-menu-mega ul.sub-menu-1 > li.menu-item:hover > a, #megaMenu ul li.menu-item.ss-nav-menu-mega ul ul.sub-menu .ss-nav-menu-header > a, #megaMenu ul li.menu-item.ss-nav-menu-mega ul.sub-menu-1 > li.menu-item > span.um-anchoremulator, #megaMenu ul li.menu-item.ss-nav-menu-mega ul ul.sub-menu .ss-nav-menu-header > span.um-anchoremulator, #megaMenu .wpmega-widgetarea h2.widgettitle {
  color:#750269;
  font-size:13px;
  font-weight:normal;
  text-shadow:0px 1px 1px transparent;
  padding-bottom:.4em;
  border-bottom:none;
  margin-bottom:.4em;
}
#megaMenu ul li.menu-item.ss-nav-menu-mega ul.sub-menu-1 > li.menu-item:hover > a { color:#ffffff; }
#megaMenu ul li.menu-item.ss-nav-menu-mega ul ul.sub-menu li.menu-item > a, #megaMenu ul li.menu-item.ss-nav-menu-mega ul ul.sub-menu li.menu-item > span.um-anchoremulator, #megaMenu ul ul.sub-menu li.menu-item > a, #megaMenu ul ul.sub-menu li.menu-item > span.um-anchoremulator {
  color:#ffffff;
  font-size:11px;
  text-shadow:0px 1px 1px transparent;
  background-color:transparent;
}
#megaMenu ul li.menu-item.ss-nav-menu-mega ul ul.sub-menu li.menu-item a:hover, #megaMenu ul ul.sub-menu > li.menu-item:hover > a {
  color:#bdde3d;
  background-color:transparent;
}
#megaMenu ul.megaMenu > li.menu-item > .wpmega-nonlink > form#searchform { padding-top:-1px; }
#megaMenu ul.megaMenu li.menu-item.ss-nav-menu-highlight > a, #megaMenu ul.megaMenu li.menu-item.ss-nav-menu-highlight > span.um-anchoremulator { color:#ffffff !important; }
#megaMenu .ss-nav-menu-with-img > a > .wpmega-link-title, #megaMenu .ss-nav-menu-with-img > a > .wpmega-link-description, #megaMenu .ss-nav-menu-with-img > a > .wpmega-item-description, #megaMenu .ss-nav-menu-with-img > span.um-anchoremulator > .wpmega-link-title, #megaMenu .ss-nav-menu-with-img > span.um-anchoremulator > .wpmega-link-description, #megaMenu .ss-nav-menu-with-img > span.um-anchoremulator > .wpmega-item-description { padding-left:21px; }
.ss-nav-menu-with-img { min-height:16px; }
#megaMenu ul.megaMenu li.menu-item a span.wpmega-item-description, #megaMenu ul.megaMenu li.menu-item span.um-anchoremulator span.wpmega-item-description {
  font-size:9px;
  line-height:1.4em;
  color:#bbbbbb;
  text-transform:uppercase;
}
#megaMenu ul.megaMenu li.menu-item.mega-with-sub > a:after, #megaMenu ul.megaMenu li.menu-item.ss-nav-menu-mega > a:after, #megaMenu ul.megaMenu li.menu-item.mega-with-sub > span.um-anchoremulator:after, #megaMenu ul.megaMenu li.menu-item.ss-nav-menu-mega > span.um-anchoremulator:after { border-top-color:transparent; }
#megaMenu ul.megaMenu li.menu-item.ss-nav-menu-reg li.menu-item.megaReg-with-sub > a:after, #megaMenu ul.megaMenu li.menu-item.ss-nav-menu-reg li.menu-item.megaReg-with-sub > span.um-anchoremulator:after { border-left-color:transparent; }
#megaMenu .wpmega-divider {
  border-top:1px solid #7b5e47;
  border-bottom:1px solid rgba(255,255,255,0.05);
}
#megaMenu.megaMenuVertical > ul > li.menu-item > a, #megaMenu.megaMenuVertical > ul > li.menu-item > span.um-anchoremulator {
  background-color:transparent;
  background:-webkit-gradient(linear,left top,left bottom,from(transparent),to(transparent));
  background:-webkit-linear-gradient(top,transparent,transparent);
  background:-moz-linear-gradient(top,transparent,transparent);
  background:-ms-linear-gradient(top,transparent,transparent);
  background:-o-linear-gradient(top,transparent,transparent);
}
#megaMenu.megaMenuVertical ul li.menu-item.ss-nav-menu-reg li.menu-item.megaReg-with-sub > a:after, #megaMenu.megaMenuVertical ul li.menu-item.mega-with-sub > a:after, #megaMenu.megaMenuVertical ul li.menu-item.ss-nav-menu-mega > a:after, #megaMenu.megaMenuVertical ul li.menu-item.ss-nav-menu-reg li.menu-item.megaReg-with-sub > span.um-anchoremulator:after, #megaMenu.megaMenuVertical ul li.menu-item.mega-with-sub > span.um-anchoremulator:after, #megaMenu.megaMenuVertical ul li.menu-item.ss-nav-menu-mega > span.um-anchoremulator:after { border-left-color:transparent; }
#megaMenu.megaMenuVertical ul.megaMenu > li.menu-item.ss-nav-menu-mega > ul.sub-menu-1, #megaMenu.megaMenuVertical ul.megaMenu li.menu-item.ss-nav-menu-reg > ul.sub-menu { border-left:; }
#megaMenu.megaMenuHorizontal ul.megaMenu { *border-bottom:none; }
#megaMenu.megaMenuVertical ul.megaMenu { *border-right:none; }
#megaMenu > ul.megaMenu > li.menu-item > .wpmega-nonlink > form#searchform.ubersearch-v2 input[type="text"] {
  color:#ffffff;
  background:#666666;
}
#megaMenu > ul.megaMenu > li.menu-item > .wpmega-nonlink > form#searchform.ubersearch-v2 input[type="submit"] {
  color:#ffffff;
  background:#666666;
}
#megaMenu > ul.megaMenu > li.menu-item > .wpmega-nonlink > form#searchform.ubersearch-v2 input[type="submit"]:hover {
  color:#ffffff;
  background:#222222;
}



/* Image Text Padding */
#megaMenu .ss-nav-menu-with-img > a > .wpmega-link-title, #megaMenu .ss-nav-menu-with-img > a > .wpmega-link-description, #megaMenu .ss-nav-menu-with-img > a > .wpmega-item-description, #megaMenu .ss-nav-menu-with-img > span.um-anchoremulator > .wpmega-link-title, #megaMenu .ss-nav-menu-with-img > span.um-anchoremulator > .wpmega-link-description, #megaMenu .ss-nav-menu-with-img > span.um-anchoremulator > .wpmega-item-description{
  padding-left: 23px;
}	
</style>
<!-- end UberMenu CSS -->
		
			<style type="text/css" data-type="vc_custom-css">.fruits-veggies p{
    color: #fff !important;
}

.homepage_products .bx-controls-direction {
    display: none;
}

.quick-picks a, .quick-picks a:hover{
    color: #ffffff !important;
    font-family: "Work Sans", serif !important;
    font-size: 13px !important;
    font-weight: 400 !important;
    line-height: 18px !important;
    letter-spacing: 1px !important;
}

.quick-picks {
    margin-bottom: 20px !important;
}

.vc_custom_1527734839755 {
    background-color: #ffffff !important;
    padding: 20px;
}

@media only screen and (max-width: 930px){
    .home-buttons > .vc_col-sm-4 {
        display: block;
    }
    .quick-picks {
        margin-bottom: 0px !important;
    }
    
    .home-buttons .vc_col-sm-4{
        margin-bottom: 0px !important;
    }
}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1508451714537{background-image: url(wp-content/uploads/about10387.png?id=206223) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1541024303458{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/hm-christmas-award.jpg?id=236384) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1531802336235{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/hm-vegebox-award.jpg?id=231458) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1532384798541{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/banner-award-carbon-neutral_1529881619.1381.jpg?id=230443) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1506983800851{padding-top: 28px !important;padding-bottom: 28px !important;}.vc_custom_1506903992486{background-color: #b8be1b !important;}.vc_custom_1506903998526{background-color: #b8be1b !important;}.vc_custom_1506904017870{background-color: #520247 !important;}.vc_custom_1506903992486{background-color: #b8be1b !important;}.vc_custom_1506903998526{background-color: #b8be1b !important;}.vc_custom_1511220410111{background-color: #b8be1b !important;}.vc_custom_1511220263878{background-color: #709743 !important;}.vc_custom_1511220276315{background-color: #f10748 !important;}.vc_custom_1511220416316{background-color: #b8be1b !important;}.vc_custom_1506984088209{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1506984223908{margin-top: 28px !important;margin-bottom: 28px !important;}.vc_custom_1510788438746{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Fruit-Vege.png?id=221115) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788449918{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Chilled-1.png?id=221116) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788461061{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Bakery-1.png?id=221117) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788471782{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Baby-1.png?id=221118) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788488887{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Beverages-1.png?id=221119) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788502356{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Health-1.png?id=221120) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788519265{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Personal-1.png?id=221121) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788542906{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Household-1.png?id=221122) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1510788559321{background-image: url(https://naturallyorganic.co.nz/wp-content/uploads/Grocery-1.png?id=221123) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
<!-- <link rel="stylesheet" href="/wp-content/themes/FrameworkFoundation/style1.min.css"> -->
</head>
<body class="home page-template-default page page-id-220939 unknown alt-style-default layout-left-content has-lightbox  wcscw-level0 wpb-js-composer js-comp-ver-4.12 vc_responsive" >

<!-- Google Tag Manager (noscript) -->


<!-- End Google Tag Manager (noscript) -->

<!-- <div class="se-pre-con"></div> -->

<noscript>
	<div class="noscript">For a better experience on Naturally Organic, enable JavaScript in your browser.</div>
</noscript>


<div style="display: none;"><strong>Current template:</strong> page.php</div>

<div id="outside_wrapper">

@extends('website_views.layout.website_layout')




<div id="my-shopping-list">
	<div class="my-shopping-list-inner row">
		<div class="sl-outer">
			<div class="sl-outer-container">
				<img src="wp-content/uploads/shopping_icon.png">
				<p>SHOPPING LIST</p>
			</div>
		</div>
		<div class="sl-inner">
			<div id="shopping-close"><img src="wp-content/uploads/close-1.png"></div>
			 <div class="shopping_list"> <form method="get" id="shopping_list_form" action="https://naturallyorganic.co.nz/shopping-list/"> <label for="shopping_list" style="font-family:'komika';color: #6E4E37;font-weight: 200;font-size: 1.2em;padding:4px 0 0 2%;">Shopping List</label> <textarea name="shopping_list" id="shopping_list"></textarea> <input type="submit" value="Search" name="search" /> </form> </diV> 		</div>
	</div>
</div>

<div id="wrapper" class="">
	       
    <div id="content" class="page col-full">
    
                
        <section id="main" class="">            

                                                                   
            <article class="post-220939 page type-page status-publish hentry">
                
                <section class="entry">


                    
<div class="vc_row wpb_row vc_row-fluid home-slideshow vc_row-o-equal-height vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<div class="vc_row wpb_row vc_inner vc_row-fluid home-slider-inner text-center vc_custom_1541024303458 vc_row-has-fill vc_row-o-equal-height vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<h2 style="text-align: center;font-family:Lato;font-weight:100;font-style:normal" class="vc_custom_heading text-white">Your Christmas Naturally</h2>
<div class="vc_btn3-container  btn-green vc_btn3-center"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-modern vc_btn3-color-grey" href="christmas/index.html" title="">Shop Now</a></div>

	<div class="wpb_text_column wpb_content_element  text-white text-center-45 fruits-veggies">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Something for everyone at Naturally Organic this Christmas</p>
<p style="text-align: center;">Allergy-Free, Vegan, Organic</p>

		</div>
	</div>
</div></div></div></div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-slider-inner text-center vc_custom_1531802336235 vc_row-has-fill vc_row-o-equal-height vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<h2 style="text-align: center;font-family:Lato;font-weight:100;font-style:normal" class="vc_custom_heading text-white">Organic Fruit &amp; Vege Boxes</h2>
<div class="vc_btn3-container  btn-green vc_btn3-center"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-modern vc_btn3-color-grey" href="product-category/fruit-vegetables/fruit-vege-boxes/index.html" title="">Shop Now</a></div>

	<div class="wpb_text_column wpb_content_element  text-white text-center-45 fruits-veggies">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Get your 5+ a day delivered straight to your door.</p>
<p style="text-align: center;">Naturally Organic has your family’s fruit and veg needs sorted. Get yours now!</p>

		</div>
	</div>
</div></div></div></div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-slider-inner text-center vc_custom_1532384798541 vc_row-has-fill vc_row-o-equal-height vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<h2 style="text-align: center;font-family:Lato;font-weight:100;font-style:normal" class="vc_custom_heading text-white">Carbon Neutral Delivery</h2>
<div class="vc_btn3-container  btn-green vc_btn3-center"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-modern vc_btn3-color-grey" href="shop/index.html" title="">Shop Now</a></div>

	<div class="wpb_text_column wpb_content_element  text-white text-center-45 fruits-veggies">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Auckland Same Day Premium Service</p>
<p style="text-align: center;">Receive a delivery-time text when your order is on its way.</p>

		</div>
	</div>
</div></div></div></div>
</div></div></div></div>
<div class="vc_row wpb_row vc_row-fluid naturally-container home-search"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1506983800851"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_center">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey">
<noscript><IMG class="vc_single_image-img " src="wp-content/uploads/feedback29aug.gif" width="749" height="77" alt="Feedback" title="Feedback"></noscript>
<img class="vc_single_image-img  lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" width="749" height="77" alt="Feedback" title="Feedback" data-src="wp-content/uploads/feedback29aug.gif">
</div>
		</figure>
	</div>
<div class="vc_empty_space" style="height: 32px"><span class="vc_empty_space_inner"></span></div>
        <div id="choose_category">
                

<div class="wc_ps_container wc_ps_sidebar_container" id="wc_ps_container_5449">
	<form class="wc_ps_form" id="wc_ps_form_5449" autocomplete="off" action="http://naturallyorganic.co.nz/search/" method="get" data-ps-id="5449" data-ps-cat_align="left" data-ps-cat_max_wide="30" data-ps-popup_wide="input_wide" data-ps-widget_template="sidebar">

				<div class="wc_ps_nav_left">
			<div class="wc_ps_nav_scope">
				<div class="wc_ps_nav_facade">
					<i class="fa fa-angle-down wc_ps_nav_down_icon" aria-hidden="true"></i>
					<span class="wc_ps_nav_facade_label">All</span>
				</div>
				<select class="wc_ps_category_selector" name="cat_in">
					<option value="" selected>All</option>
														<option data-href="https://naturallyorganic.co.nz/product-category/baby/" value="baby">Baby</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-care/" value="baby-care">   Baby Care</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-care/bathtime/" value="bathtime">      Bathtime</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-care/health-baby-care/" value="health-baby-care">      Health</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-care/skincare/" value="skincare">      Skincare</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-care/soothing-and-teething/" value="soothing-and-teething">      Soothing and teething</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/" value="baby-food">   Baby Food</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/6-plus-months/" value="6-plus-months">      6 Plus Months</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/dry/" value="dry">      Dry</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/dry-foods/" value="dry-foods">      Dry Foods</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/formula/" value="formula">      Formula</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/frozen-food/" value="frozen-food">      Frozen Food</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/jars/" value="jars">      Jars</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-food/snack-food/" value="snack-food">      Snack Food</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-mums/" value="baby-mums">   Baby Mums</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-mums/food-supplements/" value="food-supplements">      Food &amp; Supplements</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-mums/skin-body-care/" value="skin-body-care">      Skin &amp; Body Care</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/baby-mums/teas-baby-mums/" value="teas-baby-mums">      Teas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/nappies-accessories/" value="nappies-accessories">   Nappies &amp; accessories</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/nappies-accessories/baby-wipes/" value="baby-wipes">      Baby Wipes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/baby/nappies-accessories/disposable-nappies-liners/" value="disposable-nappies-liners">      Disposable Nappies &amp; Liners</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/" value="bakery">Bakery</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/baked-goods/" value="baked-goods">   Baked Goods</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/baked-goods/biscuits/" value="biscuits">      Biscuits</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/baked-goods/paleo-baked-goods/" value="paleo-baked-goods">      Paleo</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/" value="bread-by-brand">   Bread by Brand</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/bakeworks/" value="bakeworks">      Bakeworks</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/bread-butter-bakery/" value="bread-butter-bakery">      Bread &amp; Butter Bakery</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/breadman/" value="breadman">      Breadman</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/dovedale/" value="dovedale">      Dovedale</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/gluten-freedom/" value="gluten-freedom">      Gluten Freedom</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/mountain-bread/" value="mountain-bread">      Mountain Bread</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/o-m-goodness-bakery/" value="o-m-goodness-bakery">      O M Goodness Bakery</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/phoenix/" value="phoenix">      Phoenix</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/purebread/" value="purebread">      Purebread</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/thoroughbread/" value="thoroughbread">      Thoroughbread</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/bread-by-brand/venerdi/" value="venerdi">      Venerdi</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/convenience/" value="convenience">   Convenience</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/convenience/bunsbaps/" value="bunsbaps">      Buns/Baps</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/convenience/pizza-pita-wraps/" value="pizza-pita-wraps">      Pizza Pita Wraps</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/convenience/slices/" value="slices">      Slices</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/crumbs/" value="crumbs">   Crumbs</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/crumbs/gluten-free-crumbs/" value="gluten-free-crumbs">      Gluten Free</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/gluten-free/" value="gluten-free">   Gluten Free</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/gluten-free/all-bakery-lines/" value="all-bakery-lines">      All Bakery Lines</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/gluten-free/bread/" value="bread">      Bread</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/paleo-bakery/" value="paleo-bakery">   Paleo</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/paleo-bakery/bread-paleo-bakery/" value="bread-paleo-bakery">      Bread</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/pizza-bases-wraps-and-pita/" value="pizza-bases-wraps-and-pita">   Pizza Bases, Wraps and Pita</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/pizza-bases-wraps-and-pita/pizza-bases/" value="pizza-bases">      Pizza Bases</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/pizza-bases-wraps-and-pita/wraps/" value="wraps">      Wraps</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/special-occasion/" value="special-occasion">   Special Occasion</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/bakery/special-occasion/christmas/" value="christmas">      Christmas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/" value="beverages">Beverages</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/" value="coffee">   Coffee</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/allpress-organic/" value="allpress-organic">      Allpress Organic</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/altura-organic/" value="altura-organic">      Altura Organic</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/cold-brew-coffee/" value="cold-brew-coffee">      Cold Brew Coffee</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/inca-fe-organic/" value="inca-fe-organic">      Inca Fe Organic</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/instant/" value="instant">      Instant</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/kokako-organic/" value="kokako-organic">      Kokako Organic</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee/trade-aid/" value="trade-aid">      Trade Aid</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee-alternatives/" value="coffee-alternatives">   Coffee Alternatives</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee-alternatives/all-alternatives/" value="all-alternatives">      All Alternatives</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee-alternatives/instant-coffee-alternatives/" value="instant-coffee-alternatives">      Instant</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/coffee-alternatives/other/" value="other">      Other</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/" value="cold-drinks">   Cold Drinks</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/coconut-kefir-drink/" value="coconut-kefir-drink">      Coconut Kefir Drink</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/coconut-water/" value="coconut-water">      Coconut Water</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/energy-drinks/" value="energy-drinks">      Energy Drinks</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/juice/" value="juice">      Juice</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/kombucha/" value="kombucha">      Kombucha</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/meal-replacement/" value="meal-replacement">      Meal Replacement</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/probiotics-cold-drinks/" value="probiotics-cold-drinks">      Probiotics</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/sparkling-fizzy-drinks/" value="sparkling-fizzy-drinks">      Sparkling &amp; Fizzy drinks</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cold-drinks/water-kefir-drink/" value="water-kefir-drink">      Water Kefir Drink</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cordials/" value="cordials">   Cordials</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/cordials/all-cordials/" value="all-cordials">      All Cordials</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/hot-chocolate/" value="hot-chocolate">   Hot Chocolate</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/hot-chocolate/all-hot-chocolate/" value="all-hot-chocolate">      All Hot Chocolate</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/kombucha-by-brand/" value="kombucha-by-brand">   Kombucha by Brand</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/kombucha-by-brand/daily-organic-kombucha/" value="daily-organic-kombucha">      Daily Organic Kombucha</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/kombucha-by-brand/kombucha-king/" value="kombucha-king">      Kombucha King</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/kombucha-by-brand/lo-bros-organic-kumbucha/" value="lo-bros-organic-kumbucha">      Lo Bros Organic Kumbucha</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/kombucha-by-brand/organic-mechanic-kombucha/" value="organic-mechanic-kombucha">      Organic Mechanic Kombucha</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/kombucha-by-brand/remedy-organic/" value="remedy-organic">      Remedy Organic</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/" value="milk-alternatives">   Milk &amp; Alternatives</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/all-dairy-alternatives/" value="all-dairy-alternatives">      All Dairy Alternatives</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/almond-milk/" value="almond-milk">      Almond Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/coconut-milk/" value="coconut-milk">      Coconut Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/flavoured-non-dairy-milk/" value="flavoured-non-dairy-milk">      Flavoured Non-Dairy Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/fresh-goats-milk/" value="fresh-goats-milk">      Fresh Goats Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/nut-milk/" value="nut-milk">      Nut Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/oat-milk/" value="oat-milk">      Oat Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/powdered-milks/" value="powdered-milks">      Powdered milks</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/rice-milk/" value="rice-milk">      Rice Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/milk-alternatives/soy-milk/" value="soy-milk">      Soy Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/" value="tea">   Tea</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/all-our-teas/" value="all-our-teas">      All Our Teas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/black-tea/" value="black-tea">      Black tea</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/chai-tea/" value="chai-tea">      Chai tea</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/green-tea-tea/" value="green-tea-tea">      Green tea</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/herbal-tea/" value="herbal-tea">      Herbal tea</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/medicinal-tea/" value="medicinal-tea">      Medicinal tea</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/tea-making/" value="tea-making">      Tea Making</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/tea/womens-tea/" value="womens-tea">      Women's tea</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/water/" value="water">   Water</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/water/bottled-water/" value="bottled-water">      Bottled Water</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/beverages/water/boxed-water/" value="boxed-water">      Boxed Water</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/" value="chilled">Chilled</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/" value="dairy-products">   Dairy Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/butter-dairy-products/" value="butter-dairy-products">      Butter</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/cheese-dairy-products/" value="cheese-dairy-products">      Cheese</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/cream-dairy-products/" value="cream-dairy-products">      Cream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/eggs-dairy-products/" value="eggs-dairy-products">      Eggs</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/milk-dairy-products/" value="milk-dairy-products">      Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/milk-organic-a2-protein/" value="milk-organic-a2-protein">      Milk Organic A2 Protein</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/sheep-goats-milk-products/" value="sheep-goats-milk-products">      Sheep &amp; Goat’s Milk Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/sour-cream-dairy-products/" value="sour-cream-dairy-products">      Sour Cream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/dairy-products/yoghurt/" value="yoghurt">      Yoghurt</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/eggs-organic-free-range/" value="eggs-organic-free-range">   Eggs Organic &amp; Free Range</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/eggs-organic-free-range/olliff-free-range-eggs-eggs-organic-free-range/" value="olliff-free-range-eggs-eggs-organic-free-range">      Olliff Free Range Eggs</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/fish/" value="fish">   Fish</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/fish/king-fish-new-zealand/" value="king-fish-new-zealand">      King Fish New Zealand</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/fish/salmon/" value="salmon">      Salmon</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/food-to-go/" value="food-to-go">   Food To Go</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/food-to-go/salads-to-go/" value="salads-to-go">      Salads To Go</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/" value="frozen">   Frozen</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/bread-products/" value="bread-products">      Bread Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/coconut-ice-cream/" value="coconut-ice-cream">      Coconut Ice Cream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/dr-feelgood/" value="dr-feelgood">      Dr Feelgood</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/fruit-frozen/" value="fruit-frozen">      Fruit</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/ice-blocks/" value="ice-blocks">      Ice Blocks</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/ice-cream/" value="ice-cream">      Ice Cream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/meat-frozen/" value="meat-frozen">      Meat</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/pies-savouries-party/" value="pies-savouries-party">      Pies, Savouries &amp; Party</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/poultry-frozen/" value="poultry-frozen">      Poultry</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/frozen/vegetables-frozen/" value="vegetables-frozen">      Vegetables</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/goat-milk-products-chilled/" value="goat-milk-products-chilled">   Goat Milk Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/goat-milk-products-chilled/goat-cheese/" value="goat-cheese">      Goat Cheese</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/goat-milk-products-chilled/goat-feta/" value="goat-feta">      Goat Feta</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/goat-milk-products-chilled/goat-milk-products-goat-milk-products-chilled/" value="goat-milk-products-goat-milk-products-chilled">      Goat Milk Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meals/" value="meals">   Meals</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meals/bone-broth/" value="bone-broth">      Bone Broth</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meals/gf-treats/" value="gf-treats">      GF Treats</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meals/pies-savouries/" value="pies-savouries">      Pies &amp; Savouries</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meals/pitango/" value="pitango">      Pitango</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meals/tasty-pot/" value="tasty-pot">      Tasty Pot</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/" value="meat">   Meat</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/best-bones-broth/" value="best-bones-broth">      Best Bones Broth</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/bone-broth-meat/" value="bone-broth-meat">      Bone Broth</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/free-farmed-hams/" value="free-farmed-hams">      Free Farmed Hams</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/free-range-or-farmed-bacon/" value="free-range-or-farmed-bacon">      Free Range Or Farmed Bacon</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/free-range-pork/" value="free-range-pork">      Free Range Pork</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/ham-bacon/" value="ham-bacon">      Ham &amp; Bacon</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/organic-beef/" value="organic-beef">      Organic Beef</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/organic-lamb/" value="organic-lamb">      Organic Lamb</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/sausages-smallgoods/" value="sausages-smallgoods">      Sausages &amp; Smallgoods</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/taupo-grass-fed-beef/" value="taupo-grass-fed-beef">      Taupo Grass Fed Beef</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/meat/waima-hill-beef/" value="waima-hill-beef">      Waima Hill Beef</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/non-dairy-products/" value="non-dairy-products">   Non Dairy Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/non-dairy-products/coconut-products-non-dairy-products/" value="coconut-products-non-dairy-products">      Coconut Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/non-dairy-products/coconut-yoghurt-non-dairy-products/" value="coconut-yoghurt-non-dairy-products">      Coconut Yoghurt</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/non-dairy-products/dairy-free-alternative-non-dairy-products/" value="dairy-free-alternative-non-dairy-products">      Dairy Free Alternative</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/non-dairy-products/dairy-free-cheese/" value="dairy-free-cheese">      Dairy Free Cheese</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/non-dairy-products/soy-products-non-dairy-products/" value="soy-products-non-dairy-products">      Soy Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/non-dairy-products/tofu-non-dairy-products/" value="tofu-non-dairy-products">      Tofu</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/poultry/" value="poultry">   Poultry</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/poultry/chicken/" value="chicken">      Chicken</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/poultry/free-range-chicken/" value="free-range-chicken">      Free Range Chicken</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/poultry/free-range-turkey/" value="free-range-turkey">      Free Range Turkey</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/poultry/organic-chicken/" value="organic-chicken">      Organic Chicken</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soup-sauces/" value="soup-sauces">   Soup &amp; Sauces</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soup-sauces/broth/" value="broth">      Broth</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soup-sauces/curry-sauce-base/" value="curry-sauce-base">      Curry Sauce Base</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soup-sauces/sauces-soup-sauces/" value="sauces-soup-sauces">      Sauces</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soup-sauces/soups-soup-sauces/" value="soups-soup-sauces">      Soups</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soy-products/" value="soy-products">   Soy Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soy-products/soy-cheese/" value="soy-cheese">      Soy Cheese</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soy-products/soy-meat-substitutes/" value="soy-meat-substitutes">      Soy Meat Substitutes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soy-products/tempeh/" value="tempeh">      Tempeh</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/soy-products/tofu-soy-products/" value="tofu-soy-products">      Tofu</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/special-occasion-chilled/" value="special-occasion-chilled">   Special Occasion</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/special-occasion-chilled/christmas-special-occasion-chilled/" value="christmas-special-occasion-chilled">      Christmas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/spreads/" value="spreads">   Spreads</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/spreads/dairy-free/" value="dairy-free">      Dairy Free</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/spreads/pate/" value="pate">      Pate</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/vegan/" value="vegan">   Vegan</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/vegan/vegan-cheese/" value="vegan-cheese">      Vegan Cheese</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/chilled/vegan/vegan-convenience/" value="vegan-convenience">      Vegan Convenience</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/" value="fruit-vegetables">Fruit &amp; Vegetables</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/fruit/" value="fruit">   Fruit</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/fruit/dried/" value="dried">      Dried</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/fruit/fresh-fruit/" value="fresh-fruit">      Fresh Fruit</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/fruit/frozen-fruit/" value="frozen-fruit">      Frozen</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/fruit/preserved/" value="preserved">      Preserved</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/fruit-vege-boxes/" value="fruit-vege-boxes">   Fruit &amp; Vege Boxes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/fruit-vege-boxes/all-types/" value="all-types">      All Types</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/herbs/" value="herbs">   Herbs</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/herbs/fresh-herbs/" value="fresh-herbs">      Fresh Herbs</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/sprouts/" value="sprouts">   Sprouts</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/sprouts/equipment-for-sprouting/" value="equipment-for-sprouting">      Equipment for Sprouting</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/sprouts/fresh-sprouts/" value="fresh-sprouts">      Fresh Sprouts</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/sprouts/seeds-for-sprouting/" value="seeds-for-sprouting">      Seeds for Sprouting</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/vegetables/" value="vegetables">   Vegetables</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/vegetables/fresh-vegetables/" value="fresh-vegetables">      Fresh Vegetables</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/vegetables/frozen-vegetables/" value="frozen-vegetables">      Frozen Vegetables</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/fruit-vegetables/vegetables/salad-lines/" value="salad-lines">      Salad Lines</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/" value="grocery">Grocery</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/" value="baking">   Baking</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/allergy-substitutes/" value="allergy-substitutes">      Allergy Substitutes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/baking-ingredients/" value="baking-ingredients">      Baking ingredients</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/bran/" value="bran">      Bran</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/cocoa-cacao-carob-chocolate/" value="cocoa-cacao-carob-chocolate">      Cocoa, Cacao, Carob &amp; Chocolate</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/coconut-sugar/" value="coconut-sugar">      Coconut Sugar</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/crumbs-baking/" value="crumbs-baking">      Crumbs</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/flours/" value="flours">      Flours</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/food-colouring-decorating/" value="food-colouring-decorating">      Food Colouring/ Decorating</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/gluten-free-flour/" value="gluten-free-flour">      Gluten Free Flour</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/gluten-free-premixes/" value="gluten-free-premixes">      Gluten Free Premixes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/ground-nutsseeds/" value="ground-nutsseeds">      Ground Nuts/Seeds</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/milk-powders/" value="milk-powders">      Milk Powders</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/stevia/" value="stevia">      Stevia</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/sugars-sweetners/" value="sugars-sweetners">      Sugars &amp; Sweetners</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/syrups-sauces/" value="syrups-sauces">      Syrups &amp; Sauces</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/baking/vegan-jelly/" value="vegan-jelly">      Vegan Jelly</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/breakfast/" value="breakfast">   Breakfast</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/breakfast/cereal/" value="cereal">      Cereal</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/breakfast/cereal-gluten-free/" value="cereal-gluten-free">      Cereal Gluten Free</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/breakfast/lsa/" value="lsa">      LSA</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/breakfast/muesli/" value="muesli">      Muesli</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/breakfast/rolled-oats/" value="rolled-oats">      Rolled Oats</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/" value="canned-and-prepared-food">   Canned and Prepared Food</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/baked-beans-spaghetti/" value="baked-beans-spaghetti">      Baked Beans &amp; Spaghetti</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/beans/" value="beans">      Beans</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/coconut-cream-milk/" value="coconut-cream-milk">      Coconut Cream &amp; Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/condensed-milk/" value="condensed-milk">      Condensed Milk</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/fish-canned-and-prepared-food/" value="fish-canned-and-prepared-food">      Fish</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/fruit-canned-and-prepared-food/" value="fruit-canned-and-prepared-food">      Fruit</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/pesto-spreads/" value="pesto-spreads">      Pesto &amp; Spreads</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/sauerkraut/" value="sauerkraut">      Sauerkraut</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/soups/" value="soups">      Soups</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/soy-protein/" value="soy-protein">      Soy Protein</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/tomatoes/" value="tomatoes">      Tomatoes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/canned-and-prepared-food/vegetables-canned-and-prepared-food/" value="vegetables-canned-and-prepared-food">      Vegetables</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/" value="condiments">   Condiments</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/balsamic-vinegars/" value="balsamic-vinegars">      Balsamic Vinegars</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/chutnies-relish/" value="chutnies-relish">      Chutnies &amp; Relish</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/dressings-mayonnaise/" value="dressings-mayonnaise">      Dressings &amp; Mayonnaise</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/fermented-foods/" value="fermented-foods">      Fermented Foods</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/gravy/" value="gravy">      Gravy</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/herbs-spices/" value="herbs-spices">      Herbs &amp; Spices</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/mustard/" value="mustard">      Mustard</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/oils/" value="oils">      Oils</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/olives/" value="olives">      Olives</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/pepper/" value="pepper">      Pepper</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/pickles/" value="pickles">      Pickles</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/salt/" value="salt">      Salt</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/sauces/" value="sauces">      Sauces</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/seasoning-stocks/" value="seasoning-stocks">      Seasoning &amp; Stocks</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/sundried-tomatoes/" value="sundried-tomatoes">      Sundried Tomatoes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/syrups-and-sauces/" value="syrups-and-sauces">      Syrups and Sauces</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/condiments/vinegar/" value="vinegar">      Vinegar</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/honey/" value="honey">   Honey</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/honey/clover-honey/" value="clover-honey">      Clover Honey</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/honey/manuka-honey/" value="manuka-honey">      Manuka Honey</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/honey/raw-honey/" value="raw-honey">      Raw Honey</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/macrobiotic/" value="macrobiotic">   Macrobiotic</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/macrobiotic/condiment/" value="condiment">      Condiment</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/macrobiotic/miso/" value="miso">      Miso</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/macrobiotic/sea-vegetable/" value="sea-vegetable">      Sea Vegetable</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/macrobiotic/sushi-ingredients/" value="sushi-ingredients">      Sushi Ingredients</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/" value="nut-butters">   Nut Butters</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/all-nut-butters/" value="all-nut-butters">      All Nut Butters</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/almond/" value="almond">      Almond</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/cashew/" value="cashew">      Cashew</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/macadamia/" value="macadamia">      Macadamia</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/mixed-blend/" value="mixed-blend">      Mixed Blend</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/peanut/" value="peanut">      Peanut</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/sunflower/" value="sunflower">      Sunflower</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/tahini/" value="tahini">      Tahini</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nut-butters/walnut/" value="walnut">      Walnut</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nuts-seeds-dried-fruit/" value="nuts-seeds-dried-fruit">   Nuts, seeds &amp; dried fruit</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nuts-seeds-dried-fruit/dried-fruit/" value="dried-fruit">      Dried Fruit</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nuts-seeds-dried-fruit/mix/" value="mix">      Mix</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nuts-seeds-dried-fruit/nuts-nuts-seeds-dried-fruit/" value="nuts-nuts-seeds-dried-fruit">      Nuts</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/nuts-seeds-dried-fruit/seeds/" value="seeds">      Seeds</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/" value="pasta-rice-grains-pulses">   Pasta, rice, grains &amp; pulses</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/couscous/" value="couscous">      Couscous</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/gluten-free-noodles/" value="gluten-free-noodles">      Gluten Free Noodles</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/gluten-free-pasta/" value="gluten-free-pasta">      Gluten Free Pasta</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/grains/" value="grains">      Grains</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/noodles/" value="noodles">      Noodles</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/pasta/" value="pasta">      Pasta</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/polenta/" value="polenta">      Polenta</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/pulses/" value="pulses">      Pulses</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/soup-mix/" value="soup-mix">      Soup mix</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/specialty-rice/" value="specialty-rice">      Specialty Rice</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/white-rice/" value="white-rice">      White Rice</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/pasta-rice-grains-pulses/wholegrain-rice/" value="wholegrain-rice">      Wholegrain Rice</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/preserves/" value="preserves">   Preserves</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/preserves/jam/" value="jam">      Jam</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/" value="raw-foods">   Raw Foods</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/amazeballs/" value="amazeballs">      Amazeballs</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/pana-chocolate/" value="pana-chocolate">      Pana Chocolate</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/raw-bars/" value="raw-bars">      Raw Bars</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/raw-biscuits/" value="raw-biscuits">      Raw Biscuits</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/raw-cereal/" value="raw-cereal">      Raw Cereal</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/raw-chocolate/" value="raw-chocolate">      Raw Chocolate</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/raw-crackers/" value="raw-crackers">      Raw Crackers</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/raw-honey-raw-foods/" value="raw-honey-raw-foods">      Raw Honey</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/raw-foods/raw-nuts-seeds/" value="raw-nuts-seeds">      Raw Nuts &amp; Seeds</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/" value="snacks-treats">   Snacks &amp; treats</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/biscuits-snacks-treats/" value="biscuits-snacks-treats">      Biscuits</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/cakes/" value="cakes">      Cakes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/carob/" value="carob">      Carob</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/chips/" value="chips">      Chips</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/chocolate/" value="chocolate">      Chocolate</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/christmas-treats/" value="christmas-treats">      Christmas Treats</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/crackers/" value="crackers">      Crackers</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/dried-fruitfruit-bars/" value="dried-fruitfruit-bars">      Dried Fruit/Fruit Bars</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/fudge/" value="fudge">      Fudge</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/ice-cream-cones-etc/" value="ice-cream-cones-etc">      Ice Cream Cones etc</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/licorice/" value="licorice">      Licorice</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/nuts-seeds/" value="nuts-seeds">      Nuts &amp; Seeds</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/paleo/" value="paleo">      Paleo</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/popcorn/" value="popcorn">      Popcorn</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/rice-cakes/" value="rice-cakes">      Rice Cakes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/snack-muesli-bars/" value="snack-muesli-bars">      Snack &amp; Muesli bars</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/snacks-treats/sweets/" value="sweets">      Sweets</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/special-occasion-grocery/" value="special-occasion-grocery">   Special Occasion</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/special-occasion-grocery/christmas-special-occasion-grocery/" value="christmas-special-occasion-grocery">      Christmas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/special-occasion-grocery/easter-special-occasion-grocery/" value="easter-special-occasion-grocery">      Easter</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/special-occasion-grocery/mothers-day/" value="mothers-day">      Mothers Day</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/special-occasion-grocery/valentines/" value="valentines">      Valentines</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/special-occasion-grocery/vegan-christmas/" value="vegan-christmas">      Vegan Christmas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/spreads-grocery/" value="spreads-grocery">   Spreads</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/spreads-grocery/chocolate-spread/" value="chocolate-spread">      Chocolate Spread</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/spreads-grocery/jams/" value="jams">      Jams</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/spreads-grocery/nut-butters-spreads-grocery/" value="nut-butters-spreads-grocery">      Nut Butters</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/grocery/spreads-grocery/vegetable-spread/" value="vegetable-spread">      Vegetable Spread</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/" value="health">Health</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/accessories/" value="accessories">   Accessories</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/accessories/misc-accessories/" value="misc-accessories">      Misc</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/aromatherapy-massage/" value="aromatherapy-massage">   Aromatherapy &amp; Massage</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/aromatherapy-massage/essential-oils/" value="essential-oils">      Essential Oils</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/aromatherapy-massage/lotus/" value="lotus">      Lotus</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/aromatherapy-massage/massage-oils/" value="massage-oils">      Massage Oils</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/aromatherapy-massage/tui-balms-waxes/" value="tui-balms-waxes">      Tui Balms &amp; Waxes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/colds-and-flu/" value="colds-and-flu">   Colds and Flu</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/colds-and-flu/immune-support/" value="immune-support">      Immune Support</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/colds-and-flu/lozengesthroat-spray/" value="lozengesthroat-spray">      Lozenges/Throat Spray</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/colds-and-flu/symptom-relief/" value="symptom-relief">      Symptom Relief</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/detox/" value="detox">   Detox</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/detox/all-detox-products/" value="all-detox-products">      All Detox Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/detox/drinkliquids/" value="drinkliquids">      Drink/Liquids</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/detox/supplements-detox/" value="supplements-detox">      Supplements</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/detox/teas-detox/" value="teas-detox">      Teas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/first-aid/" value="first-aid">   First aid</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/first-aid/equipment-first-aid/" value="equipment-first-aid">      Equipment</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/first-aid/treatment/" value="treatment">      Treatment</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/" value="health-by-brand">   Health by Brand</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/artemis-herbal-remedies/" value="artemis-herbal-remedies">      Artemis Herbal Remedies</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/body-ecology/" value="body-ecology">      Body Ecology</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/childlife/" value="childlife">      ChildLife</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/comvita/" value="comvita">      Comvita</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/ethical-nutrients/" value="ethical-nutrients">      Ethical Nutrients</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/floradix/" value="floradix">      Floradix</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/garden-of-life/" value="garden-of-life">      Garden Of Life</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/good-health/" value="good-health">      Good Health</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/harker-herbals/" value="harker-herbals">      Harker Herbals</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/inner-health/" value="inner-health">      Inner Health</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/kiwiherb-herbal-remedies/" value="kiwiherb-herbal-remedies">      Kiwiherb Herbal Remedies</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/lifestream/" value="lifestream">      Lifestream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/melrose/" value="melrose">      Melrose</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/natures-goodness/" value="natures-goodness">      Nature's Goodness</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/natures-way/" value="natures-way">      Nature’s Way</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/one-earth/" value="one-earth">      One Earth</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/radiance/" value="radiance">      Radiance</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/red-seal/" value="red-seal">      Red Seal</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/schuessler-tissue-salts/" value="schuessler-tissue-salts">      Schuessler Tissue Salts</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/thompsons/" value="thompsons">      Thompsons</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/thursday-plantation/" value="thursday-plantation">      Thursday Plantation</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/tru-2u/" value="tru-2u">      Tru 2u</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/tui-balm/" value="tui-balm">      Tui Balm</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/udos-choice/" value="udos-choice">      UDO’s Choice</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/health-by-brand/waihi-bush/" value="waihi-bush">      Waihi Bush</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/homeopathic/" value="homeopathic">   Homeopathic</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/nutritional-oils/" value="nutritional-oils">   Nutritional Oils</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/nutritional-oils/coconut-oil/" value="coconut-oil">      Coconut Oil</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/nutritional-oils/fish-oil/" value="fish-oil">      Fish Oil</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/nutritional-oils/seed-oils/" value="seed-oils">      Seed Oils</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/remedies/" value="remedies">   Remedies</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/remedies/colloidal-silver/" value="colloidal-silver">      Colloidal Silver</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/remedies/herbal-medicine/" value="herbal-medicine">      Herbal Medicine</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/remedies/rescue-remedy/" value="rescue-remedy">      Rescue Remedy</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/remedies/sleep/" value="sleep">      Sleep</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/remedies/tissue-salts/" value="tissue-salts">      Tissue Salts</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/sanitises/" value="sanitises">   Sanitises</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/sanitises/all-sanitises/" value="all-sanitises">      All Sanitises</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/" value="superfoods">   Superfoods</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/acai/" value="acai">      Acai</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/all-superfoods/" value="all-superfoods">      All Superfoods</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/barley-wheat-grass/" value="barley-wheat-grass">      Barley &amp; Wheat Grass</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/cacao/" value="cacao">      Cacao</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/chia/" value="chia">      Chia</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/goji/" value="goji">      Goji</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/maca/" value="maca">      Maca</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/superfoods/spirulina/" value="spirulina">      Spirulina</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/" value="supplements">   Supplements</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/cultures/" value="cultures">      Cultures</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/dietary-support/" value="dietary-support">      Dietary Support</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/meal-replacement-supplements/" value="meal-replacement-supplements">      Meal Replacement</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/oils-supplements/" value="oils-supplements">      Oils</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/paleo-supplements/" value="paleo-supplements">      Paleo</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/probiotics/" value="probiotics">      Probiotics</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/protein-bars-and-cookies/" value="protein-bars-and-cookies">      Protein Bars and Cookies</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/protein-drinks-shakes/" value="protein-drinks-shakes">      Protein Drinks &amp; Shakes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/protein-powders/" value="protein-powders">      Protein Powders</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/health/supplements/vitamins-and-minerals/" value="vitamins-and-minerals">      Vitamins and Minerals</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/" value="household">Household</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/air-freshener-incense/" value="air-freshener-incense">   Air Freshener &amp; Incense</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/air-freshener-incense/all-brands/" value="all-brands">      All Brands</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/air-freshener-incense/incense/" value="incense">      Incense</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/books-magazines/" value="books-magazines">   Books &amp; Magazines</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/books-magazines/all/" value="all">      All</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/books-magazines/cook-books/" value="cook-books">      Cook Books</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/cleaning/" value="cleaning">   Cleaning</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/cleaning/bathroom/" value="bathroom">      Bathroom</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/cleaning/floors/" value="floors">      Floors</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/cleaning/glass-cleaner/" value="glass-cleaner">      Glass Cleaner</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/cleaning/kitchen/" value="kitchen">      Kitchen</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/cleaning/multipurpose/" value="multipurpose">      Multipurpose</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/" value="equipment">   Equipment</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/alka-jugs-equipment/" value="alka-jugs-equipment">      Alka Jugs &amp; Equipment</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/bags/" value="bags">      Bags</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/cleaning-equipment/" value="cleaning-equipment">      Cleaning</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/juicersblenders-slicers/" value="juicersblenders-slicers">      Juicers,Blenders &amp; Slicers</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/sprouters-seeds-for-sprouting/" value="sprouters-seeds-for-sprouting">      Sprouters &amp; Seeds For Sprouting</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/water-bottles/" value="water-bottles">      Water Bottles</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/yoghurt-accessories/" value="yoghurt-accessories">      Yoghurt Accessories</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/equipment/yoghurt-maker/" value="yoghurt-maker">      Yoghurt Maker</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/gardening/" value="gardening">   Gardening</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/gardening/bokashi/" value="bokashi">      Bokashi</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/kitchen-household/" value="kitchen-household">   Kitchen</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/kitchen-household/dish-washing/" value="dish-washing">      Dish Washing</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/" value="laundry">   Laundry</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/delicates/" value="delicates">      Delicates</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/fabric-softener/" value="fabric-softener">      Fabric Softener</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/laundry-laundry/" value="laundry-laundry">      Laundry</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/laundry-liquid/" value="laundry-liquid">      Laundry Liquid</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/laundry-powder/" value="laundry-powder">      Laundry Powder</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/pegs-etc/" value="pegs-etc">      Pegs etc</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/laundry/stain-removal/" value="stain-removal">      Stain Removal</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/paper-products/" value="paper-products">   Paper Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/paper-products/kitchen-towels-and-serviettes/" value="kitchen-towels-and-serviettes">      Kitchen Towels and Serviettes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/paper-products/lunchwrap-and-baking-paper/" value="lunchwrap-and-baking-paper">      Lunchwrap and Baking Paper</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/paper-products/tissues/" value="tissues">      Tissues</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/paper-products/toilet-paper/" value="toilet-paper">      Toilet Paper</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/pets/" value="pets">   Pets</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/pets/care/" value="care">      Care</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/pets/food/" value="food">      Food</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/" value="supplies">   Supplies</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/biodegradable-products/" value="biodegradable-products">      Biodegradable products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/fruit-vege-wash/" value="fruit-vege-wash">      Fruit &amp; Vege Wash</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/honey-wrap/" value="honey-wrap">      Honey Wrap</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/insect-control/" value="insect-control">      Insect control</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/stainless-steel-straws/" value="stainless-steel-straws">      Stainless Steel Straws</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/waste-disposal/" value="waste-disposal">      Waste Disposal</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/household/supplies/wine-neutraliser/" value="wine-neutraliser">      Wine Neutraliser</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/" value="personal">Personal</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/bath-shower/" value="bath-shower">   Bath &amp; Shower</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/bath-shower/bath/" value="bath">      Bath</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/bath-shower/body-wash/" value="body-wash">      Body Wash</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/bath-shower/hand-wash/" value="hand-wash">      Hand Wash</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/bath-shower/liquid-soap/" value="liquid-soap">      Liquid Soap</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/bath-shower/shaving-gelcream/" value="shaving-gelcream">      Shaving Gel/Cream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/bath-shower/soap/" value="soap">      Soap</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/" value="beauty-by-brand">   Beauty by Brand</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/antipodes/" value="antipodes">      Antipodes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/avalon/" value="avalon">      Avalon</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/dr-bronner/" value="dr-bronner">      Dr Bronner</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/dr-hauschka/" value="dr-hauschka">      Dr Hauschka</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/eco-by-sonya/" value="eco-by-sonya">      Eco by Sonya</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/ecostore/" value="ecostore">      Ecostore</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/giovanni/" value="giovanni">      Giovanni</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/karen-murrell/" value="karen-murrell">      Karen Murrell</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/living-nature/" value="living-nature">      Living Nature</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/purity-fragrances/" value="purity-fragrances">      Purity Fragrances</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/sukin/" value="sukin">      Sukin</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/trilogy/" value="trilogy">      Trilogy</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/beauty-by-brand/weleda/" value="weleda">      Weleda</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/deodorants/" value="deodorants">   Deodorants</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/deodorants/all-deodorants/" value="all-deodorants">      All Deodorants</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/deodorants/crystal-rock/" value="crystal-rock">      Crystal Rock</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/deodorants/roll-on/" value="roll-on">      Roll On</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/deodorants/rub-on/" value="rub-on">      Rub On</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/deodorants/spray/" value="spray">      Spray</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/deodorants/stick/" value="stick">      Stick</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/" value="feminine-care">   Feminine care</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/drion-organic-sanitary/" value="drion-organic-sanitary">      Drion Organic Sanitary</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/maternity/" value="maternity">      Maternity</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/moon-cups-accessories/" value="moon-cups-accessories">      Moon Cups &amp; Accessories</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/pads/" value="pads">      Pads</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/panty-liners/" value="panty-liners">      Panty liners</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/tampons/" value="tampons">      Tampons</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/feminine-care/wipes/" value="wipes">      Wipes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/fragrance/" value="fragrance">   Fragrance</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/fragrance/eau-de-toilette-spray/" value="eau-de-toilette-spray">      eau de toilette Spray</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/gift-basket/" value="gift-basket">   Gift Basket</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/gift-basket/all-gift-baskets/" value="all-gift-baskets">      All Gift Baskets</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/gift-basket/gift-ideas/" value="gift-ideas">      Gift Ideas</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/hair-care/" value="hair-care">   Hair care</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/hair-care/all-brands-hair-care/" value="all-brands-hair-care">      All Brands</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/hair-care/conditioner/" value="conditioner">      Conditioner</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/hair-care/hair-dye/" value="hair-dye">      Hair Dye</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/hair-care/shampoo/" value="shampoo">      Shampoo</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/hair-care/styling-products/" value="styling-products">      Styling Products</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/hair-care/treatments/" value="treatments">      Treatments</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/" value="make-up">   Make Up</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/accessories-make-up/" value="accessories-make-up">      Accessories</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/blush/" value="blush">      Blush</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/bronzer/" value="bronzer">      Bronzer</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/concealer/" value="concealer">      Concealer</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/eyeliner/" value="eyeliner">      Eyeliner</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/eyeshadow/" value="eyeshadow">      Eyeshadow</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/foundation/" value="foundation">      Foundation</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/lip-liner/" value="lip-liner">      Lip Liner</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/lip-stick/" value="lip-stick">      Lip Stick</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/mascara/" value="mascara">      Mascara</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/nail-polish/" value="nail-polish">      Nail Polish</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/powder/" value="powder">      Powder</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/make-up/tinted-moisturiser/" value="tinted-moisturiser">      Tinted Moisturiser</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/mens/" value="mens">   Mens</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/mens/deodorant/" value="deodorant">      Deodorant</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/mens/moisturiser-mens/" value="moisturiser-mens">      Moisturiser</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/mens/shavers-razors/" value="shavers-razors">      Shavers &amp; Razors</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/mens/shaving-aftershave/" value="shaving-aftershave">      Shaving &amp; aftershave</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/oral-health/" value="oral-health">   Oral health</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/oral-health/dental-floss/" value="dental-floss">      Dental Floss</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/oral-health/mouthwash/" value="mouthwash">      Mouthwash</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/oral-health/tongue-cleaners/" value="tongue-cleaners">      Tongue Cleaners</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/oral-health/toothbrushes/" value="toothbrushes">      Toothbrushes</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/oral-health/toothpaste/" value="toothpaste">      Toothpaste</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/" value="skin-care">   Skin care</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/after-sun-care/" value="after-sun-care">      After Sun Care</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/body-balm/" value="body-balm">      Body Balm</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/body-lotion/" value="body-lotion">      Body lotion</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/body-oil/" value="body-oil">      Body Oil</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/cleanser/" value="cleanser">      Cleanser</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/exfoliator/" value="exfoliator">      Exfoliator</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/eye-cream/" value="eye-cream">      Eye Cream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/face-mask/" value="face-mask">      Face Mask</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/hand-cream/" value="hand-cream">      Hand cream</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/insect-repellant/" value="insect-repellant">      Insect Repellant</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/lip-balm/" value="lip-balm">      Lip Balm</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/moisturiser/" value="moisturiser">      Moisturiser</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/self-tanbronzer/" value="self-tanbronzer">      Self Tan/Bronzer</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/serum/" value="serum">      Serum</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/sun-protection/" value="sun-protection">      Sun protection</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/toner/" value="toner">      Toner</option>
										<option data-href="https://naturallyorganic.co.nz/product-category/personal/skin-care/traveltrial-pack/" value="traveltrial-pack">      Travel/Trial Pack</option>
													</select>
			</div>
		</div>
		
		<div class="wc_ps_nav_right">
			<div class="wc_ps_nav_submit">
				<i class="fa fa-search wc_ps_nav_submit_icon" aria-hidden="true"></i>
				<input data-ps-id="5449" class="wc_ps_nav_submit_bt" type="button" value="Go">
			</div>
		</div>

		<div class="wc_ps_nav_fill">
			<div class="wc_ps_nav_field">
				<input type="text" name="rs" class="wc_ps_search_keyword" id="wc_ps_search_keyword_5449" onblur="if( this.value == '' ){ this.value = 'Search for Products'; }" onfocus="if( this.value == 'Search for Products' ){ this.value = ''; }" value="Search for Products" data-ps-id="5449" data-ps-default_text="Search for Products" data-ps-row="60" data-ps-text_lenght="15" data-ps-popup_search_in='{"product":"50","p_sku":"2","p_cat":"2","post":"2"}' data-ps-search_in="product" data-ps-search_other="product,p_sku,p_cat,post" data-ps-show_price="1">
				<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw wc_ps_searching_icon" style="display: none;"></i>
			</div>
		</div>

	
			<input type="hidden" name="search_in" value="product">
		<input type="hidden" name="search_other" value="product,p_sku,p_cat,post">
	
			</form>
</div>


        </div>
    </div></div></div></div></div></div></div></div>
<div class="vc_row wpb_row vc_row-fluid naturally-container home-buttons quick-picks">
<div class="wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1506903992486"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><a href="product-category/fruit-vegetables/vegetables/fresh-vegetables/index.html">Fresh Organic Vegetables</a></p>

		</div>
	</div>
</div></div></div></div></div></div></div>
<div class="wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1506903998526"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><a href="product-category/fruit-vegetables/fruit/fresh-fruit/index.html">Fresh Organic Fruit</a></p>

		</div>
	</div>
</div></div></div></div></div></div></div>
<div class="wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1511220410111"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><a href="product-category/fruit-vegetables/fruit-vege-boxes/index.html">Organic Fruit &amp; Vege Boxes</a></p>

		</div>
	</div>
</div></div></div></div></div></div></div>
</div>
<div class="vc_row wpb_row vc_row-fluid naturally-container home-buttons quick-picks">
<div class="wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1511220263878"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><a href="new-products/index.html">New Products</a></p>

		</div>
	</div>
</div></div></div></div></div></div></div>
<div class="wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1511220276315"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><a href="specials/index.html">Products on Special</a></p>

		</div>
	</div>
</div></div></div></div></div></div></div>
<div class="wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1511220416316"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><a href="shop/indexa1ca.html?filter_product-properties=attribute_vegan">Vegan</a></p>

		</div>
	</div>
</div></div></div></div></div></div></div>
</div>
<div class="vc_row wpb_row vc_row-fluid naturally-container mobile-remove"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984088209  vc_custom_1506984088209">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<h2 style="text-align: center;font-family:Abril Fatface;font-weight:;font-style:" class="vc_custom_heading">Popular Products</h2>
<div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">        <div id="homepage_slider">
            <div id="carousel_wrapper">
                <div id="product_carousel">
                    <ul class="home_products carousel_items">
					
					@foreach($featured_product as $fp)
                                            <li>
                            <div class="product-individual product-cart prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div> 
                                                             
                                <div class="current-qty desk-qty" data-id="235946" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="{{ url('view_product') }}/{{$fp['id']}}">
                                    <div class="product-individual-image" style="padding: 10px;">
                                        <div class="product-individual-img lazy" data-src="{{URL::asset('public/uploadimages/'.$fp['product_image'][0]['image'])}}" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>
                                    </div>
                                    <div class="product-individual-details">
                                        <div class="product-individual-name"><p>{{$fp['product_name']}}</p></div>
                                        <div class="product-individual-price">
                                            <p>
                                              <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>{{$fp['amount']}}</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>{{$fp['amount2']}}</span></ins>                                                                                        </p>
                                        </div>
                                    </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="235946">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                          
                     @endforeach                     
                                     
                                         
                                         
                                         
                                         
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div></div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
</div></div></div></div>
<div class="vc_row wpb_row vc_row-fluid naturally-container home-product-category"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788438746"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Fruit &amp; <span class="next-line">Vegetables</span></p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/fruit-vegetables/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="233736" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/asparagus-organic-bunch-200g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/0117-145x145.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Asparagus Organic Bunch 250g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4.50</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="233736">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="236183" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/banana-very-ripe-organic-kg/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/0281-145x97.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Banana Very Ripe Organic kg</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>2.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="236183">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="233594" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/spinach-organic-bunch-200g-bag/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/0037-113x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Spinach Organic Bunch 200g Bag</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4.98</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>3.98</span></ins>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="233594">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="236053" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/bananas-mexican-organically-grown-fair-trade-500g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/3534-145x96.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Bananas Mexican Organically Grown Fair Trade 500g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>2.40</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="236053">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788449918"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Chilled</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/chilled/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="8555" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/nice-blocks-raspberry-lemonade-single/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/7167-100x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Nice Blocks Raspberry Single</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4.00</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                            </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="231035" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/bu-deli-plant-based-butter-200g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/22288.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Bu Deli Plant Based Butter 200g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>6.48</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="231035">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="219478" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/biofarm-bush-honey-yoghurt-1ltr/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/1847-70x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Biofarm Bush Honey Yoghurt 1ltr</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>7.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="219478">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="9177" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/brand-chef-gluten-free-aioli-250ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/7618-145x118.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Brand Chef Gluten Free Aioli 250ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>6.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="9177">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788461061"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Bakery</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/bakery/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="168051" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/dovedale-organic-fruit-rice-bread-640g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/0688-111x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Dovedale Gluten Free Fruit &amp; Rice Bread 640g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>7.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="168051">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="7605" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/phoenix-gluten-free-chocolate-lamingtons-4pack/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/6437-145x105.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Phoenix Gluten Free Chocolate Lamingtons 4 pack</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>8.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="7605">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="159232" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/naturally-good-d-lush-chocolate-biscuits-150g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/1456-145x77.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Naturally Good D’Lush Chocolate Biscuits 150g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>6.60</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="159232">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="220183" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/gluten-freedom-sweet-potato-sourdough-buns-300g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/21976-112x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Gluten Freedom Sweet Potato Sourdough Buns 300g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>7.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="220183">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788471782"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Baby</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/baby/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="159068" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/ecostore-baby-nappy-balm-60g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/1276-145x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Ecostore Baby Nappy Balm 60g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>10.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="159068">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="201198" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/kiwiherb-baby-de-stuff-rub-28g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/20783-145x145.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Kiwiherb Baby De Stuff Rub 28g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>18.50</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="201198">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="219595" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/jack-n-jill-sweetness-bubble-bath-300ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/21958-95x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Jack N’ Jill Sweetness Bubble Bath 300ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>21.99</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="219595">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="217865" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/only-organic-vegetable-chicken-risotto-220g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/21828-145x145.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Only Organic Vegetable Chicken Risotto 220g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4.30</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="217865">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788488887"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Beverages</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/beverages/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="191913" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/inca-fe-organic-decaf-plunger-200g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/20109-121x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Inca Fe Organic Decaf Plunger 200g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>12.50</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="191913">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="229021" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/nutrition-by-nature-kombucha-brewing-kit/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/22330-145x97.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Nutrition By Nature Kombucha Brewing Kit</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>39.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="229021">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="227025" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/daily-organics-kombucha-winter-1-litre/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/19472-114x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Daily Organics Kombucha Winter 1 Litre</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>16.98</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>13.98</span></ins>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="227025">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="167546" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/phoenix-organic-lemonade-330ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/0176-59x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Phoenix Organic Lemonade 330ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>3.70</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="167546">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788502356"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Health</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/health/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="218679" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/good-health-kids-viralex-60-chewable-tablets/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/21887-87x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Good Health KIDS Viralex 60 Chewable Tablets</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>20.90</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="218679">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="218981" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/chia-co-dark-cacao-pod-170g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/21907-145x116.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Chia Co Dark Cacao Pod 170g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="218981">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="218666" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/nuzest-clean-lean-protein-chai-turmeric-maca-500g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/21884-128x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Nuzest Clean Lean Protein – Chai Turmeric &amp; Maca 500g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>55.90</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>50.30</span></ins>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="218666">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="8007" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/kefir-comany-kefir-fermented-drink-300ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/6766-80x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Kefir Company Sipper Original Kefir 300ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>16.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="8007">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788519265"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Personal</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="#"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="225138" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/neobio-nail-polish-wild-strawberry-8ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/22212-82x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Neobio Nail Polish Wild Strawberry 8ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>15.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="225138">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="8417" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/living-nature-mineral-eyeshadow-blossom/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/7059-142x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Living Nature Mineral Eyeshadow Blossom</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>24.00</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="8417">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="225128" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/neobio-nail-polish-perfect-nude-8ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/22217-80x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Neobio Nail Polish Perfect Nude 8ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>15.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="225128">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="8431" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/living-nature-mineral-eyeshadow-greenstone/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/7066-142x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Living Nature Mineral Eyeshadow Greenstone</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>24.00</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="8431">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788542906"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Household</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/household/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="5855" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/earthcare-kitchen-towels-blue-twin-pack/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/4163-123x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Earthcare Kitchen Towels Seashore Twin Pack</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4.48</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="5855">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="159964" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/ecostore-rinse-aid-lemon-200ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/2484-87x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Ecostore Rinse Aid Lemon 200ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>5.70</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="159964">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="160825" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/alka-ionised-alkaline-purified-filter-water-jug/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/8171-141x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Alka Ionised Alkaline Purified Filter Water Jug -White</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>73.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="160825">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="232084" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/born-in-nz-soap-scum-removal-500ml/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/22482-137x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Born in NZ Soap Scum Removal 500mL</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>16.18</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="232084">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid home-products">
<div class="home-products-title wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510788559321"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Grocery</p>

		</div>
	</div>
</div></div></div>
<div class="home-products-slide wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
        <div class="category-link"><a href="product-category/grocery/index.html"></a></div>

        <div class="homepage_products_slider">
            <div class="homepage_products_wrapper">
                <div class="homepage_products">
                    <ul class="home_products_category carousel_items">
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="203285" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/kokonati-organic-coconut-aminos-250m/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/20897-81x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Kokonati Organic Coconut Amino sauce 250ml</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>11.68</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="203285">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="159860" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/chantal-organic-smooth-classic-peanut-butter-700g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/2326-96x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Chantal Organic Classic Peanut Butter Smooth 700g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>15.20</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="159860">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="163657" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/orgran-pizza-pastry-multi-mix-375g/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/1070-121x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Orgran Pizza &amp; Pastry Multi Mix 375g</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>7.70</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="163657">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                            <li>
                            <div class="product-individual product-cart
                            prod-cart">
                                <div class="product-added-cover" style="height: 100%; width: 883px; display: none; opacity: 0;"><div class="product-added-cover-inner"><span><!-- <img src="/wp-content/uploads/added.png" width="55" height="55" alt="added" /> --></span></div></div>  
                                                            
                                <div class="current-qty desk-qty" data-id="183033" data-qty="0" style="display: none;">
<strong>0</strong> in your cart</div>

                                <a href="product/trade-aid-organic-indian-cashews-100gm/index.html">
                                <div class="product-individual-image" style="padding: 10px;">
                                    <div class="product-individual-img lazy" data-src="https://naturallyorganic.co.nz/wp-content/uploads/products/19390-123x150.jpg" style="background-size: contain; background-repeat: no-repeat; background-position: 50% 50%;"></div>

                                </div>
                                <div class="product-individual-details">
                                    <div class="product-individual-name"><p>Trade Aid Organic Indian Cashews 100gm</p></div>
                                    <div class="product-individual-price">
                                        <p>
                                                                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>7.98</span>                                                                                </p>
                                    </div>
                                </div>
                                </a>
                                                                                                        <div class="product-individual-add product-buttons">
                                        <div class="quantity buttons_added">
                                            <input type="button" value="-" class="minus">
                                            <input type="number" step="1" min="0" max="10" name="quantity" value="0" title="Qty" tabindex="1" class="input-text qty text" prodid="183033">
                                            <input type="button" value="+" class="plus" tabindex="1">
                                        </div>
                                    </div>
                                                                                                </div>
                        </li>
                                        </ul>
                </div>
            </div>
        </div>
        </div></div></div>
</div>
<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1506984223908  vc_custom_1506984223908">
<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e1e1e1;" class="vc_sep_line"></span></span>
</div>
<div class="vc_empty_space" style="height: 28px"><span class="vc_empty_space_inner"></span></div>
</div></div></div></div>
<div class="vc_row wpb_row vc_row-fluid about-naturally vc_custom_1508451714537 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid naturally-container"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<h3 style="text-align: center;font-family:Abril Fatface;font-weight:;font-style:" class="vc_custom_heading">About Naturally Organic</h3>
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p style="text-align: center;">Naturally Organic is your one-stop shop for affordable healthy food products for people with allergies and those wishing to live a healthy, holistic lifestyle and care for the environment. Shop online and have your organic food and groceries home delivered. The Naturally Organic Mega Lifestyle Store &amp; Café Bar in Northridge Plaza, Albany, Auckland also offers organic coffee, fresh organic smoothies and juices, and Food-to-Go which caters for many special dietary needs especially Gluten Free, Paleo, Vegan or Vegetarian, Raw Food or simply shop from our full range of great tasting, clean eating, healthy organic food options.</p>

		</div>
	</div>
<div class="vc_btn3-container  about-button vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-rounded vc_btn3-style-modern vc_btn3-color-white" href="product-category/fruit-vegetables/fruit-vege-boxes/index.html" title="">Read about our Fresh Fruit &amp; Vege box Delivery Service</a></div>
</div></div></div></div></div></div></div></div>
<div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"></div></div></div></div>
<div class="vc_row wpb_row vc_row-fluid vc_row-o-content-middle vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"></div></div></div></div>


                                    </section><!-- /.entry -->
                
            </article><!-- /.post -->
            
              
        
        </section><!-- /#main -->

        
        
    </div><!-- /#content -->
        
			<div class="footer-wrap naturally-container">
				</div><!--/.footer-wrap-->
	</div><!-- /#wrapper -->
	<div class="footer_cat_box">
		 	</div>
</div><!-- /#outside wrapper-->
	
	
	@extends('website_views.layout.footer_layout')
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
<!--[if lt IE 9]>
<script src="https://naturallyorganic.co.nz/wp-content/themes/superstore/includes/js/respond.js"></script>
<![endif]-->
			<script>
				jQuery(document).ready(function(){
					jQuery('.images a').attr('rel', 'prettyPhoto[product-gallery]');
				});
			</script>
		<link rel='stylesheet' id='vc_google_fonts_lato100100italic300300italicregularitalic700700italic900900italic-css'  href='http://fonts.googleapis.com/css?family=Lato%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic&amp;ver=4.9.6' type='text/css' media='all' />
<link rel='stylesheet' id='vc_google_fonts_abril_fatfaceregular-css'  href='http://fonts.googleapis.com/css?family=Abril+Fatface%3Aregular&amp;ver=4.9.6' type='text/css' media='all' />
<link rel='stylesheet' id='gforms_reset_css-css'  href='wp-content/plugins/gravityforms/css/formreset.min5bf8.css?ver=2.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='gforms_formsmain_css-css'  href='wp-content/plugins/gravityforms/css/formsmain.min5bf8.css?ver=2.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='gforms_ready_class_css-css'  href='wp-content/plugins/gravityforms/css/readyclass.min5bf8.css?ver=2.2.5' type='text/css' media='all' />
<link rel='stylesheet' id='gforms_browsers_css-css'  href='wp-content/plugins/gravityforms/css/browsers.min5bf8.css?ver=2.2.5' type='text/css' media='all' />
<script type='text/javascript' src='wp-content/plugins/ubermenu/core/js/hoverIntent1845.js?ver=4.9.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var uberMenuSettings = {"speed":"200","trigger":"hoverIntent","orientation":"horizontal","transition":"none","hoverInterval":"0","hoverTimeout":"200","removeConflicts":"on","autoAlign":"on","noconflict":"off","fullWidthSubs":"on","androidClick":"on","iOScloseButton":"on","loadGoogleMaps":"off","repositionOnLoad":"off"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/ubermenu/core/js/ubermenu.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-includes/js/comment-reply.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='../cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='../cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/bxslider/jquery.bxslider.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/jquery.cookie.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/bootstrap/js/bootstrap.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/jquery.lazy.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/main.min5429.js?ver=1539066267'></script>
<script type='text/javascript' src='wp-includes/js/underscore.min4511.js?ver=1.8.3'></script>
<script type='text/javascript' src='wp-includes/js/backbone.min9632.js?ver=1.2.3'></script>
<script type='text/javascript' src='wp-content/plugins/woocommerce-products-predictive-search-pro/assets/js/backbone.localStoragec5c9.js?ver=1.1.9'></script>
<script type='text/javascript' src='wp-content/plugins/woocommerce-products-predictive-search-pro/assets/js/ajax-autocomplete/jquery.autocompletef39e.js?ver=4.0.1'></script>
<script type='text/javascript' src='wp-content/plugins/woocommerce-products-predictive-search-pro/assets/js/predictive-search.backbonef39e.js?ver=4.0.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_ps_vars = {"minChars":"1","delay":"600","cache_timeout":"24","is_debug":"yes","legacy_api_url":"\/\/naturallyorganic.co.nz\/wc-api\/wc_ps_legacy_api\/?action=get_result_popup","search_page_url":"https:\/\/naturallyorganic.co.nz\/search\/","permalink_structure":"\/%postname%\/","allow_result_effect":"yes","show_effect":"fadeInUpBig"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/woocommerce-products-predictive-search-pro/assets/js/predictive-search-popup.backbonef39e.js?ver=4.0.1'></script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min8dc7.js?ver=2.6.13'></script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min8dc7.js?ver=2.6.13'></script>
<script type='text/javascript' src='wp-content/plugins/lazy-loading-responsive-images/js/lazysizes.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/jquery.jcarousel.min5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/bbt/js/jquery.lazyload.min5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/jquery-ui5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/chosen/chosen.jquery.min5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/js_functions5152.js?ver=1.0'></script>
<script type='text/javascript' src='wp-includes/js/imagesloaded.min55a0.js?ver=3.2.0'></script>
<script type='text/javascript' src='wp-includes/js/masonry.mind617.js?ver=3.3.2'></script>
<script type='text/javascript' src='wp-includes/js/wp-embed.min1845.js?ver=4.9.6'></script>
<script type='text/javascript' src='wp-content/themes/FrameworkFoundation/includes/add_to_header_cart8ad3.js?ver=1539065343'></script>
<script type='text/javascript' src='wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min0147.js?ver=4.12'></script>
<script type='text/javascript' src='wp-content/plugins/gravityforms/js/jquery.json.min5bf8.js?ver=2.2.5'></script>
<script type='text/javascript' src='wp-content/plugins/gravityforms/js/gravityforms.min5bf8.js?ver=2.2.5'></script>
<script type='text/javascript' src='wp-content/plugins/gravityforms/js/placeholders.jquery.min5bf8.js?ver=2.2.5'></script>
<script type='text/javascript'> if(typeof gf_global == 'undefined') var gf_global = {"gf_currency_config":{"name":"New Zealand Dollar","symbol_left":"$","symbol_right":"","symbol_padding":" ","thousand_separator":",","decimal_separator":".","decimals":2},"base_url":"https:\/\/naturallyorganic.co.nz\/wp-content\/plugins\/gravityforms","number_formats":[],"spinnerUrl":"https:\/\/naturallyorganic.co.nz\/wp-content\/plugins\/gravityforms\/images\/spinner.gif"};jQuery(document).bind('gform_post_render', function(event, formId, currentPage){if(formId == 2) {if(typeof Placeholders != 'undefined'){
                        Placeholders.enable();
                    }} } );jQuery(document).bind('gform_post_conditional_logic', function(event, formId, fields, isInit){} );</script><script type='text/javascript'> jQuery(document).ready(function(){jQuery(document).trigger('gform_post_render', [2, 1]) } ); </script><!-- WooCommerce JavaScript -->
<script type="text/javascript">
jQuery(function($) { 

					$( '.add_to_cart_button:not(.product_type_variable, .product_type_grouped)' ).click( function() {
						ga( 'ec:addProduct', {'id': ($(this).data('product_sku')) ? ($(this).data('product_sku')) : ('#' + $(this).data('product_id')),'quantity': $(this).data('quantity')} );
						ga( 'ec:setAction', 'add' );
						ga( 'send', 'event', 'UX', 'click', 'add to cart' );
					});
				
 });
</script>
<a href="#" class="scrollup">Scroll</a>
<!-- Hotjar Tracking Code for naturallyorganic.co.nz -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:504683,hjsv:5};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
</script>

</body>

<!-- Mirrored from naturallyorganic.co.nz/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 02 Nov 2018 17:21:53 GMT -->
</html>
