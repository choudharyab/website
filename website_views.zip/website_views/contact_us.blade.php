@extends('admin_views.layout.website_layout')
@section('content') 
<section id="wrapper">
   <div class="laberBreadcrumb">
      <div class="container">
         <nav data-depth="1" class="breadcrumb hidden-sm-down">
            <ol itemscope itemtype="">
               <li itemprop="itemListElement" itemscope itemtype="">
                  <a itemprop="item" href="{{URL::to('/')}}">
                  <span itemprop="name">Home</span>
                  </a>
                
               </li>
			    <li itemprop="itemListElement" itemscope itemtype="">
                  <a itemprop="item" href="{{URL::to('contact_us')}}">
                  <span itemprop="name">Contact Us</span>
                  </a>
                 
               </li>
            </ol>
         </nav>
      </div>
   </div>
   <aside id="notifications">
      <div class="container">
      </div>
   </aside>
            <div class="container padd_both">
      <div class="row ">
         <div id="content-wrapper">
                  <div id="left-column" class="col-xs-12 col-sm-3">
                     <div class="contact-rich">
                        <h4>Store information</h4>
                        <div class="block">
                           <div class="icon"><i class="material-icons">&#xE55F;</i></div>
                           <div class="data">Outstock Responsive Prestashop v1.7 Theme<br />United Kingdom</div>
                        </div>
                        <hr/>
                        <div class="block">
                           <div class="icon"><i class="material-icons">&#xE0CD;</i></div>
                           <div class="data">
                              Call us:<br/>
                              <a href="">0987654321</a>
                           </div>
                        </div>
                        <hr/>
                        <div class="block">
                           <div class="icon"><i class="material-icons">&#xE158;</i></div>
                           <div class="data email">
                              Email us:<br/>
                           </div>
                           <a href=""><span class="__cf_email__" data-cfemail="492d2c2426092d2c2426672a2624">[email&#160;protected]</span></a>
                        </div>
                     </div>
                  </div>
                   
                   <form enctype="multipart/form-data" id="upload_contact_form" role="form" method="POST" action="" >
                  <div id="content-wrapper" class="left-column col-xs-12 col-sm-8 col-md-9">
                     <div id="main">
                        <section id="content" class="page-content card card-block">
                           <section class="contact-form">
                              <form action="http://labbluesky.com/prestashop/v17/laber_outstock_v17/homepage3/en/contact-us" method="post" enctype="multipart/form-data">
                                 <section class="form-fields">
                                    <div class="form-group row">
                                       <div class="col-md-9 col-md-offset-3">
                                          <h3>Contact us</h3>
                                       </div>
                                    </div>
                                     @if(session()->has('message'))
                                      <div class="alert alert-success">
                                          {{ session()->get('message') }}
                                      </div>
                                       @endif
										                <div class=" ">
                                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                             <div class="fsf">
                                                <input class="form-control passs" name="full_name"  type="text" value="" placeholder="Full Name" required>
                                             </div>
                                          </div>
										                     <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                             <div class="fsf">
                                                <input class="form-control passs" name="phone_no"  type="text" value="" placeholder="Phone No." required>
                                             </div>
                                          </div>
                                          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                             <div class="">
                                                <input class="form-control passs" name="email"  type="email" value="" placeholder="Email" required>
                                             </div>
                                          </div>
                                          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                             <div class="">
                                                <textarea class="form-control" name="message" placeholder="Message"></textarea>
                                             </div>
                                          </div>
										                    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <center>  <button  type="submit" id="submit" class="btn btn-primary add-to-cart ">
                                         Send Message
                                          </button>
                  										  </center>
                  										  </div>
                                       </div>
                                  
                                  
                                  
                                 </section>
                                
                              </form>
                           </section>
                        </section>
                       
                     </div>
                     </div>
                   </form>
                  </div>
               </div>
            </div>
         </section>
		 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3721.878686100452!2d79.04474271450646!3d21.117402185950457!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd4bf8a1904e029%3A0xf83cca68b3497831!2sIT+Park+Rd%2C+Gayatri+Nagar%2C+Pratap+Nagar%2C+Nagpur%2C+Maharashtra+440022!5e0!3m2!1sen!2sin!4v1534830406608" class="map" frameborder="0" style="border:0" allowfullscreen></iframe>
		 
		 <style>
			.map{width:100%;height:450px;}
		 </style>


<style>
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default{
  
  background-color: #EEEEEE;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  
}
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default{
  background: #b343d5;
}
.ui-slider-horizontal .ui-slider-handle{
  top: -.5em;
}
.ui-slider-horizontal{
  height: .4em;
  border: 0;
  background-color: #b343d5;
  
  
}
.b{
  border-radius: 3px;
    color: #333;
    display: inline-block;
    font-size: 16px;
    font-weight: 200;
    min-width: 100%;
	text-align: center;
    transition: all 0.3s ease 0s;
  &:hover{
    background-color: darken(#b343d5,5%);
    
  }
}

.d{
  border-radius: 3px;
    color: #333;
    display: inline-block;
    font-size: 16px;
    font-weight: 200;
    min-width: 100%;
	text-align: center;
    transition: all 0.3s ease 0s;
  &:hover{
    background-color: darken(#b343d5,5%);
    
  }
}
  .ui-state-hover, .ui-widget-content .ui-state-hover, .ui-widget-header .ui-state-hover, .ui-state-focus, .ui-widget-content .ui-state-focus, .ui-widget-header .ui-state-focus,.ui-state-active{
    border-color: #b343d5;
    border-width: 3px;
    height: 1.2em;
    width: 1.2em;

    background-color: #b343d5  ;
      &:hover,&:focus,&:active{
    background-color: #b343d5;
        
  }
  }

.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default{border-color: #b343d5;}
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default{
     -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
  background-color: #b343d5;
  outline: 0;
  &:hover,&:focus,&:active{
    outline: 0;
    background-color: #b343d5;
    border-color:  #b343d5;
  }
  &:hover{
    background-color: #fff;
    &:active{
      background-color: #b343d5;
    }
  }
}
.ui-widget-header{background:#b343d5 !important;}
.ui-widget-content{background:#C1C1C1 !important;}
</style>
<script>
 $(function() {
   
$( ".a" ).slider({
range: true,
  min: 0,
max: 500,
values: [ 0, 300 ],
slide: function( event, ui ) {
$( ".b" ).text( ui.values[ 0 ] + "MM" + " - " + ui.values[ 1 ] + " MM ");
}
});
$( ".b" ).text( $( ".a" ).slider( "values", 0 ) + "MM" +
" - " + $(".a" ).slider( "values", 1 ) + " MM " );
   
});
</script>

<script>
  $(function() {
   
$( ".c" ).slider({
range: true,
min: 0,
max: 500,
values: [ 0, 300 ],
slide: function( event, ui ) {
$( ".d" ).text( "Rs." + ui.values[ 0 ] + " - Rs." + ui.values[ 1 ] );
}
});
$( ".d" ).text( "Rs." + $( ".c" ).slider( "values", 0 ) +
" - Rs." + $(".c" ).slider( "values", 1 ) );
   
});
</script>
<script>
	function show_post()
	{
		
		$(".div_data").show("slow");
		$(".div_data1").show("slow");
		$(".div_data11").hide("slow");
	}
	function hide_post()
	{
		$(".div_data").hide("slow");
		$(".div_data1").hide("slow");
		$(".div_data11").show("slow");
		
	}
</script>

<script>
   $("#submit").click(function(e){
      e.preventDefault();
         var form=$("#upload_contact_form")[0];
         var fd =new FormData(form);
          $.ajax({
               url: '{{url("store_contact_us")}}',
               data:fd,
               async:false,
               type: 'POST',
               processData: false,
               contentType: false,
              success:function(response){
              if(response.flag=="true")
                 {
                    window.location ='{{url("contact_us_success")}}';      
                 }
                 else if(response.flag=="false")
                  {  
                      alert("please enter the message");
                  } 
          },
        });
   
   });
</script>
@stop